title: css 内联元素的间隙处理
date: '2019-09-12 15:13:57'
updated: '2019-09-12 15:13:57'
tags: [前端]
permalink: /articles/2019/09/12/1568272436904.html
---
![](https://img.hacpai.com/bing/20180607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


```

 <style>
        body{
            padding: 0;
            margin: 0;
        }
        .box div{
            color: #fff;
            width: 100px;
            height: 100px;

        }
        .box div:first-child{

            background: #000;
        }
        .box div:last-child{
            background: #f34f55;
        }
        
    </style>

<body>
<div class="box">
    <div>1212</div>
    <div>2323</div>
</div>
</body>

```
![image.png](https://img.hacpai.com/file/2019/09/image-264e64d3.png)

这是默认的块元素，我们给他内联，横向安排一下。

```
 .box div{
            color: #fff;
            width: 100px;
            height: 100px;
            display: inline-block;

        }

```

![image.png](https://img.hacpai.com/file/2019/09/image-dc687d0b.png)

这里出现了一个间隙，一般是4px

改点代码

```
   .box{
            font-size: 0;
        }
        .box div{
            font-size: 16px;
            color: #fff;
            width: 100px;
            height: 100px;
            display: inline-block;

        }
```
![image.png](https://img.hacpai.com/file/2019/09/image-e6363568.png)

这里出现的间隙不是bug，就是这么设计的，，是规范。


