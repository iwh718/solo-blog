title: kotlin安卓开发：layout文件分类
date: '2019-08-20 07:21:10'
updated: '2019-08-20 07:21:10'
tags: [android]
permalink: /articles/2019/08/20/1566256870403.html
---
![](https://img-blog.csdnimg.cn/20181125194341418.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

我在layout里面直接创建了很多二级文件夹，甚至还有三级文件夹。

不可以直接使用，因为R索引获取不到，我们要到构建文件里面，加点东西。

是app的构建：加一个SourceSets配置

 ![](https://img-blog.csdnimg.cn/20181125194509662.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 一定注意：最下面是main/res   res/layout 

上面的是我们自定义的文件夹，这样你会发现，还是不行，因为：这样才可以，看出区别了么

**在我们的分类文件夹里面一定加一个layout，在它里面放我们的布局！！！**

![](https://img-blog.csdnimg.cn/20181125194631115.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

好了。
