title: 使用Parcel打包构建Vue
date: '2019-10-08 10:09:31'
updated: '2019-10-08 10:11:28'
tags: [Vue]
permalink: /articles/2019/10/08/1570500571251.html
---
![null](https://parceljs.org/assets/parcel-front.png)
最新版的Parcel支持Vue，不需要额外的插件了。

使用yarn安装Parcel工具

`yarn add parcel-bundler --dev`
`yarn add vue `

在package里面加上scripts

````
  "scripts": {
    "dev": "parcel ./index.html",
    "build": "parcel build bundle.js"
  }
`````

parcel可以通过一个入口文件自动构建打包项目，没有配置文件，相比webpack，用了它再也不想用webpack了。

运行

`yarn dev`

而且Parcel自带热更新

![image.png](https://img.hacpai.com/file/2019/10/image-db72f053.png)

