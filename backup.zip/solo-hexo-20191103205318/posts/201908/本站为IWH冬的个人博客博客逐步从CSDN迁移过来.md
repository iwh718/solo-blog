title: 本站为IWH冬的个人博客，博客逐步从CSDN迁移过来！
date: '2019-08-19 19:50:43'
updated: '2019-08-20 14:00:52'
tags: [Solo, CSDN, IWH冬]
permalink: /hello-solo
---
![独家忽而今夏4.jpg](https://img.hacpai.com/file/2019/08/独家忽而今夏4-5b417aa1.jpg)

在公司后端大佬的帮助下，通过Docker部署了Solo的博客，以后就可以在这里愉快的玩耍啦。

