title: kotlin:使用SharePreference存储集合与数组数据
date: '2019-08-20 22:59:02'
updated: '2019-08-20 22:59:02'
tags: [android]
permalink: /articles/2019/08/20/1566313142180.html
---
这里实现的是一个列表项收藏的功能，SQL太麻烦了。

数组格式：ArrayList<Map<String,Any>>

每一个list数组为一个列表项:思路就是把每次收藏的数据按照指定格式拼接存储成String。

下面是用@@拼接每个list数组，list中的map使用>分割，为了后面获取匹配！

可以自定义，泛化一下方法。

例如数据为：动漫1 地址：xx.html,动漫2，地址：xx2.html

拼接后：动漫1>xx.html@@动漫2>xx2.html   字符串！

```Kotlin
/**
 * 收藏动漫
 * @param itemId 数组下标
 * @param itemName 动漫名字
 * @param splitList 设置list分割符号
 * @param splitMap 设置map分割符号
 */
fun saveDM(itemName:String,itemId:String,splitList:String = "@@",splitMap:String=">"):Boolean{
       //这是封装的SharePreference方法，打开指定文件，指定key的值
    val likeList = iwhDataOperator.getSHP("likeKey","like","")
    //检测是否已经存在
    if(!likeList.matches(Regex(".*?${itemName}.*?"))){
        iwhDataOperator.setSHP("likeKey","$likeList$splitList$itemName$splitMap$itemId","like")
       // Log.d("@@setSHP:","${likeList}@@${itemName}>$itemId")
        return true
    }else{
        return false
    }



}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

下面就是取出返回ArrayList<Map<String,Any>>

SharePreference：动漫1>xx.html@@动漫2>xx2.html   按照这个数据，下面就不解释了。

```Kotlin
/**
 * 获取收藏
 * @return 返回收藏列表
 */
fun getSaveDM():ArrayList<Map<String,Any>?>{
    val likes:ArrayList<Map<String,Any>?> = ArrayList<Map<String,Any>?>()
    val likeList = iwhDataOperator.getSHP("likeKey","like","")
    if(likeList.isNotEmpty()){
        //匹配动漫
       val l = Regex("@@.*?.html").findAll(likeList)
        for (i in l){
            //获取名
            val l_name = Regex("@@.*?>").find(i.value)?.value?.replace(Regex("[@>]"),"").toString()
            //获取播放链接
            val l_id = Regex(">.*?.html").find(i.value)?.value?.replace(">","").toString()
            //放入MAP
            val temMap = linkedMapOf<String,Any>().apply {
                put("itemName",l_name)
                put("itemId",l_id)
            }
            //放入list
            likes.add(temMap)

        }
        Log.d("@@getLikes:",likes.toString())
        return likes
    }
    Log.d("@@getlikesERROR:","获取收藏失败！")
    return likes
}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
