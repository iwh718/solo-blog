title: Kotlin：使用带接收者的lambda的apply与with函数简化代码
date: '2019-08-20 22:56:12'
updated: '2019-08-20 22:56:12'
tags: [android]
permalink: /articles/2019/08/20/1566312972174.html
---
使用kotlin的标准库函数：with函数

iwh_tab是一个实例化的android tab组件

with函数接收两个参数，第一个是接收者，第二个是一个lambda，并且将第一个参数传入第二个lambda对象使用

我们看看基本：根据lambda约定，我们把大花括号移到外部！

```Kotlin
 with(iwh_tab,{ })
//简化后如下
with(iwh_tab){}
//iwh_tab被传入lambda
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 lambda中的this指向传入的参数iwh_tab

```Kotlin
with(iwh_tab){
            this.setSelectedTabIndicatorColor(Color.WHITE)//tab下划线颜色
            this.setTabTextColors(Color.WHITE,Color.WHITE)
            this.addTab(this.newTab().setText("基础理论与操作题"))
            this.addTab(this.newTab().setText("选择题库"))
            this.addTab(this.newTab().setText("我的"))
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 我们也可以省略this

```Kotlin
with(iwh_tab){
            setSelectedTabIndicatorColor(Color.WHITE)//tab下划线颜色
            setTabTextColors(Color.WHITE,Color.WHITE)
            addTab(this.newTab().setText("基础理论与操作题"))
            addTab(this.newTab().setText("选择题库"))
            addTab(this.newTab().setText("我的"))
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

有同学会发现，这个with函数没法返回一些需要初始化的对象，只能简化一些重复使用同一对象不同方法的场景，我们再看看另一个apply函数的使用：apply是以扩展函数实现的，该函数能够在执行lambda后返回该对象自身。

下面是一个自定义的Toast：用了with与apply，结构很简单。

```Kotlin
/**自定义 Toast
 * @author iwh
 * @param showText 自定义文本
 * @param gravity 自定义位置
 * @param type 风格
 * **/

fun iwhToast(showText: String, gravity: Int = Gravity.BOTTOM, type: Int = R.color.right) {

    val iwhContext = App._context
    val setParame = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    val iwhText = TextView(iwhContext).apply {
        setTextColor(Color.WHITE)
        textAlignment = TextView.TEXT_ALIGNMENT_CENTER
        setPadding(5, 5, 5, 5)
        layoutParams = setParame

    }
//使用apply初始化一个组件，后面会用到，所以用apply
    val iwhLyout = LinearLayout(iwhContext).apply {
        layoutParams = setParame
        setBackgroundResource(type)
        addView(iwhText)
    }
//使用with执行组件的显示，不需要返回该对象
   with( Toast.makeText(App.getContext(), showText, Toast.LENGTH_SHORT)){
        setGravity(Gravity.FILL_HORIZONTAL or gravity, 0, 0)
        view = iwhLyout
        setMargin(0f, 0f)
        iwhText.text = showText
        show()
    }

}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
