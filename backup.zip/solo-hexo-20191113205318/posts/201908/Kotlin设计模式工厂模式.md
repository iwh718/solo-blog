title: Kotlin设计模式：工厂模式
date: '2019-08-20 23:00:49'
updated: '2019-08-20 23:00:49'
tags: [kotlin, 设计模式]
permalink: /articles/2019/08/20/1566313249514.html
---
本篇继续练习kotlin设计模式之工厂模式，Factory，这个模式许多第三方类库都在使用，但是对于一般简单的对象类型还是直接使用新建比较好。用工厂反而繁琐，多此一举。

上代码：很直观，就不多说了。

```Kotlin
package KotlinMode

/**
 * 工厂模式
 */

interface Fruits {
    fun showName()
}

class Lemon(private val strType: String) : Fruits {
    override fun showName() {
        println("当前构建对象是：$strType")
    }
}
class Pear(private val strType: String) : Fruits by Lemon(strType)
class Watermelon(private val strType: String) : Fruits by Lemon(strType)

/**
 * 创建工厂
 */
class FruitsFactory {

    fun createType(type: String): Fruits? {
        return when (type) {
            "Pear" -> {
                Pear(type)
            }
            "Watermelon" -> {
                Watermelon(type)
            }
            "Lemon" -> {
                Lemon(type)
            }
            else -> null
        }
    }

}


fun main() {

    val lemon = FruitsFactory().createType("Lemon")
    lemon?.showName()
    val watermelon = FruitsFactory().createType("Watermelon")
    watermelon?.showName()
    val pear = FruitsFactory().createType("Pear")
    pear?.showName()


}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

输出：

![](https://img-blog.csdnimg.cn/201904122218495.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
