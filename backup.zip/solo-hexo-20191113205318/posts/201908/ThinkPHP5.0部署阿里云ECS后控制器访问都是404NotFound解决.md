title: ThinkPHP5.0 部署阿里云ECS后，控制器访问都是404 NotFound解决
date: '2019-08-20 07:24:47'
updated: '2019-08-20 07:24:47'
tags: [待分类]
permalink: /articles/2019/08/20/1566257087390.html
---
。。。原因是服务器不支持Pathinfo模式，使用 public/index.php?s=控制器/xx 就可以了。
