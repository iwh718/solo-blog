title: Ant-Design-Vue $nitication与$message全局配置
date: '2019-08-20 07:23:22'
updated: '2019-08-20 07:23:22'
tags: [Vue]
permalink: /articles/2019/08/20/1566257002734.html
---
使用ant里这两个组件需要进行全局配置：

```javascript
import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false;
//注入全局属性$message
import { message,notification } from 'ant-design-vue'
Vue.prototype.$message = message;
Vue.prototype.$notification = notification;
message.config({
    duration: 2,
});
new Vue({
  render: h => h(App),
}).$mount('#app')
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

在Main.js，在Vue的原型链增加这两个属性。在其他子组件里就可以通过$引用了。

```javascript
this.$message.info("提交完成！")

 this.$notification.open({
                    message: '这是一条通知!',
                    description: '这是描述内容！.',
                    icon: <a-icon type="smile" style="color: #108ee9"/>,
                    onClick: () => {
                        console.log('你点击了通知');
                    },
                });
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
