title: pyCharm安装Tensorflow
date: '2019-09-09 17:55:39'
updated: '2019-09-21 09:51:29'
tags: [tensorflow]
permalink: /articles/2019/09/09/1568022939322.html
---
![null](https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1569040759566&di=0a03627aec31d83716c4fe33cb25afb7&imgtype=0&src=http%3A%2F%2Fimg.zishu010.com%2FArticleImage%2F2018%2F5%2Fe637659df0364ef682abc50b1e5f9394.jpg)

1.注意最新的Python3.7余Tensorflow不兼容（因为关键字Async）
2.安装Python3.6
3.使用pip安装tf，如果出现超时，换pip源

```
pip install  tensorflow==1.11 -i https://pypi.tuna.tsinghua.edu.cn/simple/
```

测试：

```
import tensorflow as tf

if __name__ == '__main__':
    x = [[2.]]
    m = tf.matmul(x, x)
    print("hello, {}".format(m))
```

![image.png](https://img.hacpai.com/file/2019/09/image-5944c21e.png)

