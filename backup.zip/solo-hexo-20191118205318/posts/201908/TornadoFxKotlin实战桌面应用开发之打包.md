title: TornadoFx-Kotlin实战桌面应用开发之打包
date: '2019-08-19 22:06:33'
updated: '2019-08-19 22:06:43'
tags: [Kotlin, TornadoFx]
permalink: /articles/2019/08/19/1566223592903.html
---
前段时间学习使用TornadoFx一个kotlin版的javaFx框架开发了一个应用，完成后，第一次遇到打包jar文件（之前一直写JS前端和PHP后端，从来没用过java），心累啊，然后就是打包成为EXE格式的程序。

这篇文章只做打包的记录，至于TornadoFx的开发笔记，有空会放上来（还有使用Jfoenix一个fx的质感设计库）。

上个图看看。用的Jfoenix库（其中涉及到kotlin调用有点小问题，不过大部分正常使用）。

![](https://img-blog.csdnimg.cn/20190606210745487.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 其中涉及到各种基本组件与高级组件，属性绑定，表格渲染，REST接口请求。

下面看看项目结构：kotlin为原生代码，resources为资源文件，kotlin里面默认资源访问路径就是这里。

JavaFx可以使用FXML编写界面，TornadoFx也可以，但是kotlin1的DSL得到了很大的利用，写起来很棒，就没有用FXML写页面了。全部使用DSL编写。

![](https://img-blog.csdnimg.cn/20190606211128519.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

一点布局代码

```Kotlin
    val header = StackPane().apply {
            vbox {
                alignment = Pos.CENTER
                label("图书馆查询·外网版"){
                    textFill = Color.WHITE

                }
                label {
                    textFill = Color.WHITE
                    text = "图书数据不完整，更多请使用校内版！"
                }
                flowpane {
                    hgap = 5.0
                    vgap = 5.0
                    paddingAll = 10.0
                    //spacing = 10.0
                    this += myButton("设计")
                    this += myButton("营销")
                    this += myButton("公司")
                    this += myButton("商业")
                    this += myButton("机械")
                    this += myButton("高数")

                    this += myButton("JAVA")
                    this += myButton("Cad")
                    this += myButton("Android")
                    this += myButton("Max")
                    this += myButton("Python")
                    this += myButton("PhotoShop")

                }
            }
            style {
                backgroundColor += c("#4d4d4d")
                VBox.setVgrow(this@apply, Priority.ALWAYS)
            }
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 进入正题：打包项目

1：找到Structure，添加Artifacts：选择JAR-From moudule

![](https://img-blog.csdnimg.cn/20190606211517316.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

2：接下来是关键：主类，你可以选择默认的，他会帮你搜索项目的主类，你可能会有两个主类出现在选择中，一个是fx项目主类，一个是main函数顶级主函数（这个在IDE中效果不大，但是后面打包EXE有用！），这里你选择项目主类就可以了，顶级主函数是以xxKt.kt结尾的函数，这是TornadoFx自动处理的！

还有就是：MANIFEST文件的位位置，如果不正确，打包后，运行会出现：找不到清单文件，把路径改为图2 src后面的删除！

添加完后，依赖会自动被打包，但是资源文件不会，你需要添加资源文件resources到打包。

![](https://img-blog.csdnimg.cn/20190606211641522.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20190606212012481.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 接下来：点击 build 

![](https://img-blog.csdnimg.cn/2019060621210679.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 3:完成后：out目录

![](https://img-blog.csdnimg.cn/20190606212137113.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 jar文件是我们打包完成的，你可以直接运行它，如果直接双击失败或者没反应，就使用命令行执行 java -jar TornadoDemo.jar 后出现报错信息，你就可以查错了。

到这里如果运行正常，就可以正常使用了，但是这个是jar文件，很多用户并没有安装JRE环境，怎么办呢还有很多用户都不知道JAR是可以直接运行的，在大多数普通用户眼里，EXE才是windows的正常应用，so，我们需要用到：EXE4J这个软件了，他可以打包JAR文件到EXE还能添加自带JRE（这不是必须，但是你想要的你的应用在所有设备运行，请带上它，或找个精简版的，因为它有点大。。。）

开始打包：  
1.![](https://img-blog.csdnimg.cn/20190606212603267.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

2：![](https://img-blog.csdnimg.cn/20190606212619803.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

3：![](https://img-blog.csdnimg.cn/20190606212652919.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

4：你可以设置icon图标路径，并添加64余32位的支持，还要输出应用的名字

 ![](https://img-blog.csdnimg.cn/20190606212716161.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20190606212754271.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

![](https://img-blog.csdnimg.cn/20190606212806529.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

5：![](https://img-blog.csdnimg.cn/2019060621284895.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

6：点击加号，添加我们刚开始导出的JAR文件。![](https://img-blog.csdnimg.cn/20190606213017726.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 7：添加主函数：这一步很多人发现是空白，因为你没写主函数，而是直接使用IDE的运行来跑，IDE自动使用的Application方法。

![](https://img-blog.csdnimg.cn/20190606213125228.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

IDE中Main函数

![](https://img-blog.csdnimg.cn/20190606213319231.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

8：选择运行的JRE版本，可以不填上限。![](https://img-blog.csdnimg.cn/20190606213353956.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

9：选择JRE：如果不使用默认的JRE寻找方式（就是根据系统变量去查找用户电脑JRE的位置），想把JRE直接打包进去，选择高级设置选择sequence添加自己的JRE注意是相对路径，把默认的删除！

![](https://img-blog.csdnimg.cn/20190606213430764.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20190606213622556.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

10：选择客户端完成

![](https://img-blog.csdnimg.cn/20190606213659232.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20190606213756540.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

好了。打包EXE完成。

关于使用TornadoFx，后续会记录，网上有很多都是跑个官方Demo基本没什么用，在编写这个应用，遇到了许许多多的问题，由于没有javaFx开发经验，遇到不少问题，虽然TornadoFx的文档说，没有fx经验不影响学习，但是还是需要去了解fx的基本原理比如：架构，stage与scene，属性绑定等，这在TornadoFx默认出现了。。。

  

后续会将这个项目放置GitHub，目前在完善。

 合个影：

![](https://img-blog.csdnimg.cn/20190606214302469.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

