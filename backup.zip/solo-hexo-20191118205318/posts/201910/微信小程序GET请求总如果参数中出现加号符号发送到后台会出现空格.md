title: 微信小程序GET请求总，如果参数中出现’+'加号符号，发送到后台会出现空格
date: '2019-10-23 11:52:05'
updated: '2019-10-23 11:52:27'
tags: [微信小程序]
permalink: /articles/2019/10/23/1571802725227.html
---



如果加上请求头呢：

```javascript
 header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

还是空白的话，就手动编码处理一下，是处理特殊的地方：

```javascript
 url = url.replace(/\+/g,"%2B");
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

这里把+号处理一%2B就好了。
