title: 易班轻应用开发：PHP版
date: '2019-08-20 23:01:31'
updated: '2019-08-20 23:01:31'
tags: [易班, PHP]
permalink: /articles/2019/08/20/1566313291707.html
---
最近易班的APP接入了我们学校，虽然很多地区评价为毒瘤，流氓等等，应用市场评价也是最低级别。但是，作为开发者，就不管它了，本文写的是一个查询成绩的轻应用（传送门：[青果教务查成绩](https://mp.csdn.net/postedit/83473481)），这里就只说说，如何接入易班接口。

由于，查询成绩的应用，是爬虫获取的，其实也没必要调用易班接口，但是，使用易班接口，可以在后台查看使用情况，这点倒是很方便啦。贴一个小图：

![](https://img-blog.csdnimg.cn/20190419095837819.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 下面开始介入易班：使用的PHP版SDK，首先去易班下载（传送门：[PHP_SDK](https://o.yiban.cn/wiki/index.php?page=SDK%E4%B8%8B%E8%BD%BD)）

下载下来，有三个类型的SDK，我们选择轻应用，然后有两个文件夹：classes和demo

classes目录：

  

![](https://img-blog.csdnimg.cn/2019041910011174.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

demo：这里config有两个，请忽略2，因为上传Git，有些内容（APPKEY）需要保留。

apitest：演示了如何使用示例接口。

config:配置你的APPkey和秘钥与授权完成，回调页面。

iapp：请求获取授权。

revoke：取消授权

index:演示程序的首页

![](https://img-blog.csdnimg.cn/20190419100212510.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

SDK的接口很清晰了，异常，转码，接口，入口。

易班官网给了这么个流程图：。。。

![](https://img-blog.csdnimg.cn/20190419100651657.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

总的来说：就是应用初始化时候，去请求易班接口，查询是否用户已经授权，如果授权，则重定向到应用首页（这一步，易班API自动完成，我们填写个回调页面就ok）。当然，你也可以直接弄一个页面引导用户授权。

下面是我应用的首页代码：首先获取API实例，然后就检查授权状态：perform()，接下来获取token，这里调用的基本信息API，其它的自行查阅官网。代码中的bind($token)是绑定现在的token，如果继续调用其它接口，就不用了传token了。API请求使用request()，返回的数据是JSON格式。下面是拿到了授权用户的昵称（实名需要更高的权限，需要申请）。

```php
session_start();
require("./classes/yb-globals.inc.php");
require_once './config.php';
//初始化
    $api = YBOpenApi::getInstance()->init($config['AppID'], $config['AppSecret'], $config['CallBack']);
    $iapp  = $api->getIApp();
    
    try {
       //轻应用获取access_token，未授权则跳转至授权页面
       $info = $iapp->perform();
    } catch (YBException $ex) {
       echo $ex->getMessage();
    }
    $token = $info['visit_oauth']['access_token'];//轻应用获取的token
    $_SESSION['token'] = $token;
    $api->bind($token);
    //获取基本用户信息
    $userInfo = $api->request('user/me');
    //去除用户名
    $info = $userInfo['info'];
    //存储到Session
    $_SESSION['userName'] = $info['yb_username']

 ?>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

这是自动检测授权，还有一种就是我们主动发起授权申请：state是防止跨站伪造的参数，这里用的时间戳。

这个页面会主动调取授权请求。

```php
<?php
session_start();
require('../config.php');
$AppID  = $config['AppID'];
$AppSec = $config['AppSecret'];
$CALLBACK  = $config['CallBack'];
$state = time();
header("Location: https://openapi.yiban.cn/oauth/authorize?client_id=$AppID&redirect_uri=$CALLBACK&state=$state");
?>

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

下面是撤销授权:

```php
<!DOCTYPE html>
<html>
<head>
	<title>xx</title>
	<meta charset="UTF-8">
</head>
<body>

<?php
session_start();
//回收授权操作
$token = $_SESSION['token'];

/**
 * 包含SDK
 */
require("../classes/yb-globals.inc.php");

// 配置文件
require_once 'config.php';

$api = YBOpenApi::getInstance()->init($config['AppID'], $config['AppSecret'], $config['CallBack']);
$api->bind($token);
?>
<p>调用取消用户授权后的返回结果</p>
<p>
<?php 
$res = $api->request('oauth/revoke_token', array('client_id'=>$api->getConfig('appid')), true);
?>
</p>
<p><?php if ($res['status']==200) {?>撤销授权成功，下次访问DEMO时会重新要求用户授权<?php }?></p>
<a href="http://f.yiban.cn/iapp390020">返回首页！</a>

</body>
</html>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

  

好了。其它接口的信息大家可以自行查询官网。

  

最后有个要注意的地方：如果你是在本地测试，授权页面填写本地的就好了，如果是上线了，就填写易班站内地址，不然授权会报错，提示不是应用内发起授权申请。

```php
<?php
    /**
	 * 配置文件(轻应用)
	 */
	$config = array(
	    'AppID'     => 'xxx',     //appid
	    'AppSecret' => 'xxx',     //AppSecret
	    'CallBack'  => 'http://f.yiban.cn/iappxxx,      //授权回调地址,轻应用站内地址
	);
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
