title: PHP解析小程序提交的JSON为NULL报错代码：4
date: '2019-11-03 04:03:22'
updated: '2019-11-03 04:04:25'
tags: [PHP]
permalink: /articles/2019/11/03/1572725002694.html
---
小程序端提交：userInfo数组，userInfo:JSON.stringify(e.detail.userInfo)后。

PHP后端总是解析报错：$error:4

```
 $raw_data = $this->request->param('userInfo');
                $raw_data = htmlspecialchars_decode($raw_data);
                $data = json_decode($raw_data,true);
                $err = json_last_error();
```

查了好久，各种改，最后发现是反斜杠被转译，PHP的decode无法识别。。。。。

加上htmlspecialchars_decode就好了，弄到快天亮。无语。
