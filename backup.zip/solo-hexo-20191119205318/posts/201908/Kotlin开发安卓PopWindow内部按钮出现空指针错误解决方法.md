title: Kotlin 开发安卓PopWindow 内部按钮出现空指针错误！解决方法
date: '2019-08-20 07:16:47'
updated: '2019-08-20 07:16:47'
tags: [android, kotlin]
permalink: /articles/2019/08/20/1566256607776.html
---
错误：按钮事件监听发生异常

```Kotlin
Attempt to invoke virtual method 'void android.widget.Button.setOnClickListener
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

原因是pop导入的xml布局不是main的布局，所有没法直接用set监听事件

解决：用pop布局.findViewById就好啦！

```Kotlin
 val loginPop_view: View = LayoutInflater.from(this@MainActivity).inflate(R.layout.add, null, false)
 val mark_ok = loginPop_view.findViewById<Button>(R.id.add_ok)
 mark_ok.setOnClickListener {
                Snackbar.make(view,"完成",Snackbar.LENGTH_SHORT).show()
            }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
