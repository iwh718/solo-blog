title: Kotlin安卓开发：ViewPage的动态刷新
date: '2019-08-20 22:49:21'
updated: '2019-08-20 22:49:21'
tags: [android]
permalink: /articles/2019/08/20/1566312561430.html
---
总是遇到一个问题:

```html
无法动态刷新ViewPage里的Fragment
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

ViewPage里使用的是Fragment，list_fg就是一个fg集合、

```Kotlin
  list_fg.removeAt(msg.arg1)
  Log.d("msg:",msg.arg1.toString())
  iwh_view_page_adapter.notifyDataSetChanged()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

这里接收要移除的fg下标就是msg.arg1

然后调用view_page_adapter.notifyDataSetChanged()

感觉是可以，实际无效、

我们实现viewPage的adapter类有两个

最开始用得是：FragmentPagerAdapter

发现，出现一个问题，删除第一个fg，结果最后一个fg没了。然后，下次进入后，第一个没了，最后一个正常、

而且从最后开始删除，就不会出现这个情况，百度一下，发现是继承的这个adapter类的问题，他会缓存当前fg和旁边的fg

所以没办法立即删除。

```html
默认getItemPOsition会返回无状态改变，这里要重写一下，返回强制改变状态。这个可以百度相关资料，缺点是会重新绘制所有的fg
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

![](https://img-blog.csdnimg.cn/20181129131349249.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

```html
换成：FragmentStatePagerAdapter
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

就好了。
