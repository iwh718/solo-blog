title: 使用Docker在windows搭建Solo博客
date: '2019-08-20 13:38:58'
updated: '2019-09-22 10:30:41'
tags: [Docker]
permalink: /articles/2019/08/20/1566279538847.html
---

	最近，旁边的后端大佬使用Docker搭建了一个java的博客系统，很是新奇，应该说发现一个新玩具一样，一个是Docker，另一个就是很漂亮的Solo博客。

在大佬的帮助下很快就在服务器上部署好了solo，惊呆了，没有像之前我部署PHP那样，即使使用集成的服务器环境也要调整很多文件与配置，而Docker一下子，全都解决了，然后像Git一样把Solo博客的镜像，Pull了下来，就可以部署访问了！！👍 

简直了，相比PHPStudy与wamp这样的环境，Docker的概念，我是刚接触，很是好奇。为了方便修改博客的CSS表，于是就开始了本地部署Docker来运行[Solo](https://github.com/b3log/solo)（一个很轻简约的博客系统）

于是开始了我的踩坑：第一个就是Docker一般是部署在Linux上，而我的开发机器是Win10,并且还是家庭版（Docker要求是专业版，还有版本限制）

下面看看如何解决：

如果你是Win10可以直接下载Desktop版Docker

正常安装完后会生成快捷方式：如果你遇到了错误，看下面：

![image.png](https://img.hacpai.com/file/2019/08/image-8aed63e2.png)



1.解决提示说：Hyper-V 未开启的方法：

![image.png](https://img.hacpai.com/file/2019/08/image-3f88e7a6.png)

打开功能

![image.png](https://img.hacpai.com/file/2019/08/image-3e584a13.png)

![image.png](https://img.hacpai.com/file/2019/08/image-6e978ebe.png)

![image.png](https://img.hacpai.com/file/2019/08/image-ee16d241.png)

如果你的电脑没有这个，说明没有安装（专业版一般自带）

然后你可以使用下面的命令在CMD输入：如果直接输入报错，就写入文本文件，后缀改为xx.cmd 使用管理员执行。

```
pushd "%~dp0"

dir /b %SystemRoot%\servicing\Packages\*Hyper-V*.mum >hyper-v.txt

for /f %%i in ('findstr /i . hyper-v.txt 2^>nul') do dism /online /norestart /add-package:"%SystemRoot%\servicing\Packages\%%i"

del hyper-v.txt

Dism /online /enable-feature /featurename:Microsoft-Hyper-V-All /LimitAccess /ALL
```

多等一会，直到安装完成。然后重启电脑。

如果安装完成后：双击Docker安装文件，还提示版本或者虚拟化未开启：

1.修改注册表：运行 regedit->打开注册表，定位到HKEY_LOCAL_MACHINE\software\Microsoft\Windows NT\CurrentVersion，点击current version，在右侧找到EditionId，右键点击EditionId 选择“修改“，在弹出的对话框中将第二项”数值数据“的内容改为Professional，然后点击确定
2.进入BISO，配置选项启用Hyper

重启后，正常情况下就可以启动Docker了，右下角会有一个小鲸鱼。
![image.png](https://img.hacpai.com/file/2019/08/image-7d8cee9b.png)


试一下docker的命令
![image.png](https://img.hacpai.com/file/2019/08/image-2ca56a4c.png)


安装数据库


 docker pull mysql:5.7.20

设置Solo的数据库（移步GitHub-Solo）

 ```
docker run --detach --name solo  --publish 8080:8080 --env RUNTIME_DB="H2" --env JDBC_USERNAME="root" --env JDBC_PASSWORD="123456" --env JDBC_DRIVER="org.h2.Driver" --env JDBC_URL="jdbc:h2:/opt/solo/h2/db;MODE=MYSQL" b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost --server_port=8080
```



启动Solo服务

`Docker start Solo` 

打开浏览器

![image.png](https://img.hacpai.com/file/2019/08/image-bc32f50f.png)

