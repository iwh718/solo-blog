title: Kotlin开发 SQLite使用
date: '2019-08-20 07:17:16'
updated: '2019-08-20 07:17:16'
tags: [android, kotlin]
permalink: /articles/2019/08/20/1566256636273.html
---
 

```Kotlin
//这里是写的工具类
class wenSql(context: Context, name: String, factory: SQLiteDatabase.CursorFactory?, ver: Int) : SQLiteOpenHelper(context, name, factory, ver) {
        val Create_ = "Create table wen(id integer primary key autoincrement,title text , url text);"//SQL语句
        val mContext = context
        var marks = arrayListOf<Map<String, Any>>()//存放数据
        override fun onCreate(db: SQLiteDatabase?) {
try {
        db!!.execSQL(Create_)
        // Toast.makeText(mContext, "初始化完成！", Toast.LENGTH_SHORT).show()
} catch (e: NullPointerException) {
        println(e)
}

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {}

    fun wen_add(title: String, url: String, db: SQLiteDatabase,hand:Handler): Boolean {
    try {
        var cv = ContentValues()
        cv.put("title", title)
        cv.put("url", url)
        Log.d("添加：",cv.getAsString("title"))
        Log.d("添加：",cv.getAsString("url"))

        db.insert("wen", null, cv)
        cv.clear()
        var msg = Message()
        msg.what = 2
        hand.sendMessage(msg)
        return true
    } catch (e: NullPointerException) {
        var msg = Message()
        msg.what = 0
        hand.sendMessage(msg)//通知UI线程刷新数据
        return false
    }
}
        fun wen_delete(sql: String): Boolean {
            return false
    }

        fun wen_query(id: String, db: SQLiteDatabase, hand: Handler): Boolean {
            var cursor = db.query("wen", null, null, null, null, null, null, null)
            if (cursor.moveToFirst()) {
                do {
                    var temMAp = linkedMapOf<String, Any>()
                    var title = cursor.getString(cursor.getColumnIndex("title"))
                    var url = cursor.getString(cursor.getColumnIndex("url"))
                    temMAp.put("title", title)
                    temMAp.put("url", url)
                    marks.add(temMAp)
                    // println(temMAp)
                    //temMAp.clear()
            } while (cursor.moveToNext())
            println(marks)
            val msg = Message()
            msg.what = 1
            hand.sendMessage(msg)
            cursor.close()
        }
    return false
}

fun wen_update(sql: String): Boolean {
return false
    }

}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
