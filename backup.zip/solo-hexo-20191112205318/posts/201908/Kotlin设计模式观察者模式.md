title: Kotlin设计模式：观察者模式
date: '2019-08-19 22:18:06'
updated: '2019-08-19 22:19:09'
tags: [设计模式, kotlin]
permalink: /articles/2019/08/19/1566224286724.html
---
![null](https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1566234418486&di=3411d134d8a726bd9bd1792d78284759&imgtype=0&src=http%3A%2F%2Fwww.itcast.cn%2Ffiles%2Fimage%2F201812%2F20181224095009056.jpg)
kotlin与java基本使用方法一样，不过写法更简洁。

观察者，感觉就是多个事件源与一个订阅者，订阅者订阅多个事件源，当订阅者接收数据时候，所有的事件源都触发并更新数据。

换成观察者，就是，一个目标对象状态改变，其它观察它的对象都收到通知，并改变，像广播一样。

用kotlin代码实现如下：之前在菜鸟写过笔记，有一处错误，被观察者后面的 订阅者 -》修改为 被订阅者。

```Kotlin
/**
 * 观察者
 */
interface Observer {
    fun <T : Any?> update(msg: T)
}

/**
 * 观察者1,2,3
 */
class Ob1(private val id: Int = 0) : Observer {
    override fun <T> update(msg: T) {
        println("接收消息，观察者$id:$msg")
    }
}
//这里是kotlin的类委托
class Ob2 : Observer by Ob1(2)
class Ob3 : Observer by Ob1(3)

/**
 * 被观察者（被订阅）
 */
class Subject {

    //存放观察者
    private  var observers =  ArrayList<Observer>()
    //订阅观察者
    fun attach(ob: Observer) {
        observers.add(ob)
    }
    //设置数据
    fun <T : Any?> setMsg(msg: T) {
        this.notify(msg)
    }
    //更新数据
    private fun <T : Any?> notify(msg: T) {
        for (iOb in this.observers) {
            iOb.update(msg)
        }
    }
}

/**
 * Kotlin版 观察者模式
 * @author IWH
 * Des：kotlin1.3支持主函数省略参数
 */
fun main() {

    val sub = Subject().apply {
        attach(Ob1())
        attach(Ob2())
        attach(Ob3())
    }
    with(sub){
        setMsg(123)
        setMsg("hello world")
        setMsg('A')
        setMsg(null)
    }
}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

输出：

![](https://img-blog.csdnimg.cn/20190411205346752.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
