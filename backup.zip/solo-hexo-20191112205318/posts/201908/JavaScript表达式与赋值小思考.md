title: JavaScript 表达式与赋值 小思考
date: '2019-08-20 23:04:09'
updated: '2019-08-20 23:04:09'
tags: [JavaScript]
permalink: /articles/2019/08/20/1566313449415.html
---
今天群里一个小伙伴用短路运算，在 || 后面用了赋值语句，语法检查过不去，是为啥呢？

想起来以前看的一篇关于表达式的文章

> 表达式（expression）是JavaScript中的一个短语，JavaScript解释器会将其计算出一个结果。
> 
> 将简单表达式组合成复杂表达式最常用的方法就是使用运算符（operator）。运算符按照特定的运算规则对操作数进行运算，并计算出新值。

而圆括号就是一种分组运算符，直接使用赋值，并没有返回给运算符结果，用了（），执行赋值后，会返回一个结果。

我们来测试一下：a就是表达式返回的结果，如果没有括号，从语法上首先过不去，因为它只是赋值，没有运算，没有返回，而括号有，返回什么呢，这里应该是true，因为是||运算，第一个为false，就不继续了，看第二个。

```javascript
       let flag = true;
       let test = "123";
       let a =  test === "123" || (flag = false);
                                    //这里如果括号去除，会报错
       console.log(a)
       console.log(flag)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

![表达式（expression）是JavaScript中的一个短语，JavaScript解释器会将其计算出一个结果。 将简单表达式组合成复杂表达式最常用的方法就是使用运算符（operator）。运算符按照特定的运算规则对操作数进行运算，并计算出新值。](https://private.codecogs.com/gif.latex?%25u8868%25u8FBE%25u5F0F%25uFF08expression%25uFF09%25u662FJavaScript%25u4E2D%25u7684%25u4E00%25u4E2A%25u77ED%25u8BED%25uFF0CJavaScript%25u89E3%25u91CA%25u5668%25u4F1A%25u5C06%25u5176%25u8BA1%25u7B97%25u51FA%25u4E00%25u4E2A%25u7ED3%25u679C%25u3002%20%25u5C06%25u7B80%25u5355%25u8868%25u8FBE%25u5F0F%25u7EC4%25u5408%25u6210%25u590D%25u6742%25u8868%25u8FBE%25u5F0F%25u6700%25u5E38%25u7528%25u7684%25u65B9%25u6CD5%25u5C31%25u662F%25u4F7F%25u7528%25u8FD0%25u7B97%25u7B26%25uFF08operator%25uFF09%25u3002%25u8FD0%25u7B97%25u7B26%25u6309%25u7167%25u7279%25u5B9A%25u7684%25u8FD0%25u7B97%25u89C4%25u5219%25u5BF9%25u64CD%25u4F5C%25u6570%25u8FDB%25u884C%25u8FD0%25u7B97%25uFF0C%25u5E76%25u8BA1%25u7B97%25u51FA%25u65B0%25u503C%25u3002)![](https://img-blog.csdnimg.cn/20190713120221895.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

再看看第二种：这回，括号的返回成功了：true，同时flag与被改变了。

```javascript
      let flag = false;
       let test = "123";
       let a =  (flag = true);
       console.log(a)
       console.log(flag);
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

![](https://img-blog.csdnimg.cn/20190713120648820.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

看看我们这个问题：就好解决了。

![](https://img-blog.csdnimg.cn/2019071311501362.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

因为，这里需要的是表达式，不是语句，有用过React的同学应该见过return后面总会跟个（），因为要返回的是一个表达式结果，不是一个赋值操作，上面的正确写法是：

![](https://img-blog.csdnimg.cn/20190713115222526.png)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
