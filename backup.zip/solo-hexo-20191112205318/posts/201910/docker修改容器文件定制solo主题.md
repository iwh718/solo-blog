title: docker修改容器文件，定制solo主题。
date: '2019-10-14 17:36:05'
updated: '2019-10-14 20:07:34'
tags: [Docker]
permalink: /articles/2019/10/14/1571045765238.html
---
使用CP命令将docker容器文件复制到主机

`docker cp 容器名称:/文件路径 /主机路径`

复制主机文件到docker容器
`
docker cp /主机文件路径 容器名字:/容器文件路径`


使用xshell进行远程连接管理docker。

使用xftp上传修改的文件，就可以修改定制solo主题了。


