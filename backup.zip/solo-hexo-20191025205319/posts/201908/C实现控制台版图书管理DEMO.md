title: C++实现控制台版图书管理DEMO
date: '2019-08-20 07:15:33'
updated: '2019-08-20 07:15:33'
tags: [小玩意]
permalink: /articles/2019/08/20/1566256533720.html
---
上学期，学了C语言，期末是写一个管理系统，额，用得C++写的，第一次用C++，也是最后一次，哈哈！

（遇到主要是如何查找指定行的图书，并删除，这里用的是临时生成一个新文件，复制图书数据除你要找的其余部分，到新的文件，然后删除源文件，最后把新文件重命名就好了）

  

![](https://img-blog.csdn.net/20180918203432991?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

熟悉的控制台，哈哈。

实现了，图书入库，图书查询，图书检索，图书删除。

```cpp
#include<iostream>
#include<string>
#include <stdio.h>
#include<fstream>
#include <cstdio>
#define MAX 100
//author：bore
//time:2018.6
//图书类：增。删，查，输出 
 class Book{
 	
 	public:
 		
 		void b_show();//输出函数 
 		void b_join();//增加图书 
 		void b_clear();//清除缓存 
		std::string b_search(int s_n2);//搜索函数
		void b_delete();//删除函数 
		std::string b_number,b_name,b_author,b_price,b_info;
			
 }; 
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

1.首先定义一个图书类，方法有，展示UI，入库，清除缓存，搜索，删除。

2.定义每个图书的信息，书名，编号，作者，价格等。

3.下面是具体的函数定义

```cpp
void Book::b_clear(){

std::cin.ignore(100,'\n');

};
//清除缓冲区字符 

void Book::b_join(){
	std::ofstream f_join("info.txt",std::ios::app);
	if(f_join.is_open()){
		
		std::cout<<"请依次输入：编号 书名 作者 价格 |然后回车确认\n";
	    std::cin>>this->b_number>>this->b_name>>this->b_author>>this->b_price;
	    f_join<<"编 号："<<this->b_number<<" 书名："<<this->b_name<<" 作者："<<this->b_author
		<<" 价格："<<this->b_price<<" 元"<<"\n";
	   
		f_join.close();
		std::cout<<"已经录入\n"<<"回车回到主菜单\n";
		std::cin.get();
		f_join.close();
		b_clear(); 
	
	}else{
		std::cout<<"读取文件出错";
	}	
}; 
//添加图书数据
 
void Book::b_show(){
	std::cout<<"以下为所有图书信息\n\n";
	std::string info;
	std::ifstream f_show("info.txt");
	if(f_show.is_open()){
		
		while(std::getline(f_show,info)){
		if(info!=""){
			std::cout<<info<<"\n\n";
		}		
		}
	}else{
		std::cout<<"读取文件出错";
	}
	f_show.close();
	std::cout<<"回车键回到主菜单";
	b_clear(); 
	
};
//读取图书数据 

void Book::b_delete(){
	int i=1,flag;
	std::string info;
	std::string b_box[MAX];
	std::ifstream f_show("info.txt");
	if(f_show.is_open()){
		std::string tem_info;

		tem_info=this->b_search(1); 
	
		if(tem_info!="2"){
		while(std::getline(f_show,info)){
				b_box[i]=info;
				if(b_box[i]==tem_info){
					
					flag=i;
				
				}
				//std::cout<<b_box[i]<<"\n\n";
			++i;
			}
		f_show.close();			
		b_box[flag]="";
			std::ofstream f_join("info2.txt",std::ios::app);
	if(f_join.is_open()){
	
	for(int i;i<MAX;i++){
		f_join<<b_box[i]<<"\n";
	}
	f_join.close();
	 if(remove("info.txt")==0){
	 	std::cout<<"删除完成";
	 }else{
	 	std::cout<<"删除失败";
	 
	 	std::cin.get();
	 }
	 if(rename( "info2.txt" , "info.txt" )==0){
	 	std::cout<<"重命名成功"; 
	 }
	
	
	std::cin.get(); 
	
	}
		
		
		}else{
		std::cout<<"你输入的图书不存在！";
		}
		std::cin.get();
	}else{
		std::cout<<"注意，本地文件不存在！";
		std::cin.get();
	}
	

};
//图书删除 

std::string Book::b_search(int s_n2){
	std::string info;
	std::ifstream f_show("info.txt");
	
	if(s_n2==1||s_n2==2){
		int i=1;
		std::string tem_info;
		std::cout<<"请输入图书编号回车\n\n"; 
		std::cin>>this->b_number;
		
			
		if(f_show.is_open()){
		
			while(std::getline(f_show,info)){
			
				if(info.find(this->b_number)!=std::string::npos){
					std::cout<<"找到这本书了,在第："<<i<<"行\n\n"
					<<info<<"\n\n";
					tem_info=info;
				
				
					break;
					
				}
			++i;
			}
				return tem_info;
		}else{
			std::cout<<"读取文件出错";
		}
		f_show.close();
	
		std::cin.get();
	}else{
		std::cout<<"输入错误";
		std::cin.get();
	}

};
//图书检索 
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

接下来是主函数了。

```cpp
int main(){
	for(;;)//无循环回到主菜单 
{

	std::cout<<"*************************************************\n"
			 <<"***                                           ***\n"
			 <<"***        C++版图书管理程序demo：bore        ***\n"
			 <<"***                                           ***\n"
			 <<"***             基本功能如下                  ***\n"
			 <<"***                                           ***\n"
			 <<"***             1:图书录入+                   ***\n"
			 <<"***                                           ***\n" 
			 <<"***             2:图书浏览+                   ***\n"
			 <<"***                                           ***\n"
			 <<"***             3:图书删除                    ***\n"
			 <<"***                                           ***\n"
			 <<"***             4:图书检索+                   ***\n"
			 <<"***                                           ***\n"
			 <<"***             5:退出管理+                   ***\n"
			 <<"*************************************************\n"; 
	std::cout<<"选择序号回车进入\n";
	int s_n,s_n2;//选择一级/二级选项 
	std::cin>>s_n;//输入一级选项 
	std::cin.ignore(100,'\n');//清除字符 
	Book book;//实例化Book对象 
	switch(s_n){
		case 1 :	std::cout<<"你选择的是,图书录入，回车下一步";
					book.b_clear();
					book.b_join();
					std::cout<<"\n";break;
					
		case 2 :    std::cout<<"你选择的是，图书浏览，回车下一步";
					book.b_clear();
					book.b_show();
				    std::cout<<"\n";break;
					
		case 3 :    std::cout<<"你的选择是，图书删除，回车下一步";
					book.b_clear();
					book.b_delete();
					std::cin.get();
					std::cout<<"\n";break;
					
		case 4 :    std::cout<<"你的选择是，图书检索，回车下一步";
					book.b_clear();
					std::cout<<"请输入你要检索的方式，图书编号（1）或者名称（2），回车进行下一步\n";
					std::cin>>s_n2;
					std::cin.ignore(100,'\n');
					book.b_search(s_n2); 
					std::cin.get();
				    std::cout<<"\n";break;
				    
		case 5 :    std::cout<<"你的选择是，退出系统，回车下一步";
					exit(0);break;
					
		default:    std::cout<<"输入格式错误,请重新输入，回车退出\n";
					book.b_clear();
					std::cout<<"\n";break; 
	}
}

	return 0; 
} 
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

好啦，这是上学期写的，现在都快忘记语法了，语言真是不写就生疏。

仅仅是demo，而且没有用上C++的高级部分，还是用了数组，因为，我只看到数组，后面的没看，就干别的了。

不过最近用的kotlin，有些语法超级像C++！
