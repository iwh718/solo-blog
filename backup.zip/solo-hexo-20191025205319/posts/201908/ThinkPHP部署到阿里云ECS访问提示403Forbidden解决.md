title: ThinkPHP部署到阿里云ECS访问提示403 Forbidden 解决
date: '2019-08-20 07:24:26'
updated: '2019-08-20 07:24:26'
tags: [ThinkPHP]
permalink: /articles/2019/08/20/1566257066367.html
---
这个问题折腾很久，网上都是说什么主机没配置好，我用的是PHP'Study创建多个站点之后，由于Tp要绑定到Public目录，所以注意：要把Public目录的权限修改为可读取的纂改，不然外网无法访问的。
