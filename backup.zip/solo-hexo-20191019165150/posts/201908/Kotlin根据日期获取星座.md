title: Kotlin：根据日期获取星座
date: '2019-08-20 22:53:39'
updated: '2019-08-20 22:53:39'
tags: [kotlin]
permalink: /articles/2019/08/20/1566312819826.html
---
在群里看到一个同学的期末作业是根据日期返回星座，可能为了防止抄袭，要求加上诞生石。。

其实没啥区别啊。。。

下面是代码：

```Kotlin
override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val (inputM,inputD,goBtn,outText)  = arrayOf(
            findViewById<TextInputEditText>(R.id.inputMonth),
            findViewById<TextInputEditText>(R.id.inputDay),
            findViewById<Button>(R.id.goBtn),
            findViewById(R.id.outText))
        var (iMonthText,iDayText) = arrayOf("","")
       goBtn.setOnClickListener{
         iMonthText =  inputM.text.toString()
           iDayText = inputD.text.toString()

           if(iMonthText.isNotEmpty() && iDayText.isNotEmpty()) {

               outText.text = Constellation.star(iMonthText.toInt(),iDayText.toInt())
               Toast.makeText(this@MainActivity,Constellation.star(iMonthText.toInt(), iDayText.toInt()),Toast.LENGTH_SHORT).show()
           } else {
               Toast.makeText(this@MainActivity, "不可以输入空！", Toast.LENGTH_SHORT).show()
           }

       }


    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

工具类：

```Kotlin
package com.simplewen.win0.checkluckybound

class Constellation{
    companion object {
        fun star(m:Int,d:Int):String{
            var res = "格式错误！"
            val date = intArrayOf(20, 19, 21, 20, 21, 22, 23, 23, 23, 24, 23, 22)
            val index = m//索引
            val luckyData = arrayListOf<Map<String,Any>>(
                mapOf("星座:" to "摩羯座,诞生石：土耳其玉" ),
                mapOf("星座:" to "水瓶座,诞生石：紫水晶"),
                mapOf("星座:" to "双鱼座，诞生石：月长石" ),
                mapOf("星座:" to "白羊座，诞生石：钻石" ),
                mapOf("星座:" to "金牛座，诞生石：蓝宝石" ),
                mapOf("星座:" to "双子座，诞生石：玛瑙" ),
                mapOf("星座:" to "巨蟹座，诞生石：珍珠" ),
                mapOf("星座:" to "狮子座，诞生石：红宝石"),
                mapOf("星座:" to "处女座，诞生石：红条纹玛瑙" ),
                mapOf("星座:" to "天秤座，诞生石：蓝宝石" ),
                mapOf("星座:" to "天蝎座，诞生石：猫眼石" ),
                mapOf("星座:" to "射手座，诞生石：黄宝石" ),
                mapOf("星座:" to "摩羯座，诞生石：土耳其玉")
            )
            when(m){
                1,2,3,4,5,6,7,8,9,10,11,12->{
                    when(d){
                        in  1..31 ->
                            if(d < date[m-1]){
                                res = luckyData[index-1]["星座:"].toString()
                            }else{

                                res = luckyData[index]["星座:"].toString()
                            }
                        else -> res  = "天数格式错误！"
                    }

                }
                else ->{
                     res = "月份格式错误！"
                   
                }
            }

            return res
        }
    }

}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

其实也没什么区别。

下面是图

![](https://img-blog.csdnimg.cn/20190106223522395.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
