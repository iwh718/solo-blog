title: 关于unicode编码中&amp;amp;#和&amp;amp;#x转换中文问题
date: '2019-08-19 22:13:54'
updated: '2019-08-19 22:13:54'
tags: [Bug修复]
permalink: /articles/2019/08/19/1566224033929.html
---
关于&#x转换中文有很多资料，这里是&#的方法：

&#编码后面跟的是十进制的unicode数字。

[https://ourcodeworld.com/articles/read/188/encode-and-decode-html-entities-using-pure-javascript](https://blog.csdn.net/u010913414)

上面的文章是英文的，里面介绍了如何编码与解码。

下面是我用的：

```html
 eg = unescape(eg.replace(/&#(\d+);/g, function (match, eg) {
          return String.fromCharCode(eg);
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

eg是字符串，里面是含有&#xxxxx编码的内容，小程序不支持直接显示，需要转换为中文，

用得replace函数，/g全局匹配，参数二是一个函数，把编码的字符解码为中文unicode

用得是fromCharCode函数把&#xxxxx去除&#后的编码换成中文的。

具体过程可以参考链接内容。
