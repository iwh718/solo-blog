title: 微信小程序PHP后端接口使用JWT验证
date: '2019-08-20 23:02:23'
updated: '2019-08-20 23:02:23'
tags: [PHP, JWT]
permalink: /articles/2019/08/20/1566313342993.html
---
以前写小程序接口都是裸奔（因为想着SSL可以保护一下），再然后就是谁没事搞我的个人小玩意。

现在有一个小项目需要使用接口，想着还是加个验证吧，一直裸奔也不太好。小程序没法使用web的session，突然想起前端早八点小程序推送过一篇关于JWT（ JSON Web Token）的方法。

简单说一下，就是你第一次访问接口的时候，比如是登录，如果登录完成，服务器会下发一个token，这个token是有期限的，还附加一个playload，还有别的，这里使用最简洁的用法，当你拿到这个token，以后每次去访问接口，都会验证是否被篡改，如果token解密正确，则接口返回数据，怎么验证呢，第一个按照原先的加密方式，解密，之后，还要检查过期时间，防止被拿到token一直被爬数据，时间一到，还要重新申请。你也可以把token放到数据库里，每次访问接口验证用户id就好了。

为了快速简单的使用：我从GitHub找了一个写好的工具类（最后我会把JWT的地址放上）

看看用法：这里是发放token，至于逻辑，可以自行处理，我用的是微信的wx.login去请求微信的session来确认是否发放token。

eg：可以选择算法，作者用的是PHP内置的一些加密方式，我在token的exp上设置了20分钟过期。

```php
<?php

/*
 * Copyright(c)2011 Miguel Angel Nubla Ruiz (miguelangel.nubla@gmail.com). All rights reserved
 */

require_once "JWT.php";

$header = '{"typ":"JWT",
 "alg":"HS256"}';

$exp = time() + 20 * 60;
$payload = '{"iss":"iwh","isOk":true,"exp":'.$exp."}" ;

$key = '1234567890';

$JWT = new JWT;

$token = $JWT->encode($header, $payload, $key);
$json = $JWT->decode($token, $key);

echo 'Header: '.$header."\n\n";
echo 'Payload: '.$payload."\n\n";
echo 'HMAC Key: '.$key."\n\n";

echo 'JSON Web Token: '.$token."\n\n";
echo 'JWT Decoded: '.$json."\n\n";

?>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

token输出：可以看到解密正常。

![](https://img-blog.csdnimg.cn/20190621190511224.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 之后，每次请求都带上这个发放的token，就好了。你可以根据自己需要更改逻辑与过期时间。

  

JWT文件：

```php
<?php

/*
 * Copyright(c)2011 Miguel Angel Nubla Ruiz (miguelangel.nubla@gmail.com). All rights reserved
 */

class JWT {
    private $alg;
    private $hash;
    private $data;
    
    private function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function base64url_decode($data) {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
    
    public function encode($header, $payload, $key) {
        $this->data = $this->base64url_encode($header) . '.' . $this->base64url_encode($payload);
        return $this->data.'.'.$this->JWS($header, $key);
    }
    
    public function decode($token, $key) {
        list($header, $payload, $signature) = explode('.', $token);
        $this->data = $header . '.' . $payload;
        if ($signature == $this->JWS($this->base64url_decode($header), $key)) {
            return $this->base64url_decode($payload);
        }
        exit('Invalid Signature');
    }
    
    private function setAlgorithm($algorithm) {
        switch ($algorithm[0]) {
            case n:
                $this->alg = 'plaintext';
                break;
            case H:
                $this->alg = 'HMAC';
                break;
            // By now, the only native is HMAC
            /* 
            case R:
                $this->alg = 'RSA';
                break;
            case E:
                $this->alg = 'ECDSA';
                break;
            */
            default: exit("RSA and ECDSA not implemented yet!");
        }
        switch ($algorithm[2]) {
            case a:
                $this->alg = 'plaintext';
                break;
            case 2:
                $hash = 'sha256';
                break;
            case 3:
                $hash = 'sha384';
                break;
            case 5:
                $hash = 'sha512';
                break;
        }
        if (in_array($hash, hash_algos())) $this->hash = $hash;
    }

    private function JWS($header, $key) {
        $json = json_decode($header);
        $this->setAlgorithm($json->alg);
        if ($this->alg == 'plaintext') {
            return '';
        }
        return $this->base64url_encode(hash_hmac($this->hash, $this->data, $key, true));
    }
}

?>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

GitHub有很多很好的JWT，但是这个既简单由能快速使用。
