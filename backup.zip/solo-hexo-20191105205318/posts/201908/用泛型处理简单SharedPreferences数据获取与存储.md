title: 用泛型处理简单SharedPreferences数据获取与存储
date: '2019-08-20 22:55:47'
updated: '2019-08-20 22:55:47'
tags: [android]
permalink: /articles/2019/08/20/1566312947060.html
---
 android中封装SharePreference可以使用这种方法。

```Kotlin
import com.sun.org.apache.xpath.internal.operations.Bool
import kotlin.reflect.KFunction

object Toperator{

    /**获取泛型数据
     * @param getType 获取数据类型
     * **/
   fun<T> getT(getType:T):T?{
        var res:T? = null
       when(getType){
           is Int ->{
                res = getType
               println("获取整形:$getType")
           }
           is String ->{
               res = getType
               println("获取字符串:$getType")
           }
           is Boolean ->{
               res = getType
               println("获取布尔:$getType")
           }
           is Double ->{
               res = getType
               println("获取双精度:$getType")
           }
           else ->{
               println("类型不匹配！")
           }

       }
        return res
   }
    /**存储泛型数据
     * @param saveT 存储数据
     * @return 链式调用**/
    fun<T> setT(saveT:T):Toperator{
        when(saveT){
            is Int ->{
                println("存储整形:$saveT")
            }
            is String ->{
                println("存储字符串:$saveT")
            }
            is Boolean ->{
                println("存储布尔:$saveT")
            }
            else ->{
                print("数据类型不匹配！")
            }
        }
        return  Toperator
    }

}

fun main(args:Array<String>){

   arrayOf(
           Toperator.getT("0"),
           Toperator.getT(0),
           Toperator.getT(1.0),
           Toperator.setT(arrayListOf("")))
    Toperator.setT(1111).setT("111").setT(true).setT(arrayListOf(""))

    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

![](https://img-blog.csdnimg.cn/20190118163255513.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
