title: 如何定制solo的Freemark皮肤并预览
date: '2019-08-22 17:54:37'
updated: '2019-08-23 07:59:26'
tags: [Solo, 后端]
permalink: /articles/2019/08/22/1566467677461.html
---
![](https://img.hacpai.com/bing/20190529.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


因为工作需要，solo自带的皮肤需要定制化，但是FTL的模板第一次接触，记录一下，定制的小总结。

我是个前端，solo是需要java环境的，于是我在本地的docker上进行部署，然后，通过docker来修改皮肤文件。
上一篇文章说了如何使用Docker在windows部署solo，现在，启动docker。

进入PoswerShell

`docker start solo`

然后 进入容器
`docker exec -it solo sh`

![image.png](https://img.hacpai.com/file/2019/08/image-c8b7c054.png)


如果你按照网上的输入 bash 可能会提示不存在 因为 solo只有shell。

进入容器后，我们看一下目录

`pwd`

看一下文件列表

`ls`
![image.png](https://img.hacpai.com/file/2019/08/image-d70331ba.png)

skins里面就是solo内置的皮肤了，我们可以选择一款进行定制化修改。

`cd skins`
![image.png](https://img.hacpai.com/file/2019/08/image-1abce245.png)


接下来是将solo的皮肤文件复制到主机上，本来公司大佬说可以开启共享目录就能不用复制了，但是我用的家装版win10，一堆问题，就改用了复制，将皮肤文件复制出来一份进行修改，然后直接cp到容器内部，刷新浏览器，就可以看到修改的模板效果了（模板虽然是FTL，但是里面的模板变量和其它模板文件都差不多的，基本不影响我们定制html与css，如果你需要更好的方式，可以使用npm来处理样式与其它文件）

复制命令

`docker cp D:xxx主机地址 solo:/opt/solo/skins/xx`



