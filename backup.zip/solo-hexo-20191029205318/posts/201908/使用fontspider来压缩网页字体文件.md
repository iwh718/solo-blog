title: 使用font-spider来压缩网页字体文件
date: '2019-08-31 11:36:54'
updated: '2019-08-31 11:39:31'
tags: [yarn]
permalink: /articles/2019/08/31/1567222614776.html
---
![](https://img.hacpai.com/bing/20190330.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1.由于网页使用了自定的字体，导致首次加载异常缓慢，使用yarn安装一个工具包：font-spider来压缩字体文件。

流程

```
yarn  add font-spider

scripts:{"sf":"font-spider *.html"}

yarn run sf

```

随后你会发现字体文件体积减小的非常多，看情况应该是font-spider扫描了html文件里使用的字体，去除了字体文件中未使用的字。

注意点：TTF格式可以压缩，Otf不行！

生成后，会有有个.font-spider的隐藏文件夹，内部是压缩前的字体，可以自行删除。

![image.png](https://img.hacpai.com/file/2019/08/image-ca4f3eb3.png)

8M的字体压缩后。

