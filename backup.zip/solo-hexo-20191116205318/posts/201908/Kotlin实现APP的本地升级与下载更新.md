title: Kotlin：实现APP的本地升级与下载更新
date: '2019-08-20 22:52:20'
updated: '2019-08-20 22:52:20'
tags: [android]
permalink: /articles/2019/08/20/1566312740695.html
---
这里就不写服务端的东西了。

```Kotlin
class Utils{
    /**@param CheckUp 检查版本更新 **/


    companion object {
        val versionUrl = "http://www.xxx.com"//获取版本号
        val versionWd =  "https://www.sxxx/xx.apk"//获取Apk文件
        fun Tos(str:String){
            Toast.makeText(WdTools.getContext(),str,Toast.LENGTH_SHORT).show()
        }

        fun requestUpVersion(hand:Handler){
            var versionOld = 0
            val client = OkHttpClient.Builder().build() //初始化请求
            thread {

                //构建请求
                val request = Request.Builder().url(versionUrl).build()
                client.newCall(request).enqueue(object : Callback {
                    override fun onResponse(call: Call, response: Response) {

                        val resText = response.body()?.string()
                        val temResText: String? = resText
                        versionOld = temResText!!.replace(" ","").toInt()
                        Log.d("@@versionWD:",versionOld.toString())
                        val msg = Message()
                        msg.what = 0x21
                        msg.arg1 = versionOld
                        hand.sendMessage(msg)

                    }

                    override fun onFailure(call: Call, e: IOException) {
                        val msg = Message()
                        msg.what = 0x22
                        hand.sendMessage(msg)
                    }
                })


            }

        }
        //实现下载apk
        fun DownNew():Long{


            val  request = DownloadManager.Request(Uri.parse(versionWd))
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            request.setDestinationInExternalFilesDir(WdTools.getContext(), Environment.DIRECTORY_DOWNLOADS,"wd.apk")
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            // 设置 Notification 信息
            request.setTitle("正在下载xx更新")
            request.setDescription("下载完成后请点击打开")
            request.setVisibleInDownloadsUi(true)
            request.allowScanningByMediaScanner()
            request.setMimeType("application/vnd.android.package-archive")

            // 实例化DownloadManager 对象
           val downloadManager = WdTools.getContext().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            return downloadManager.enqueue(request)
        }

        /**
         * 获取版本号
         */

       fun getVersion(activity:Activity):Int{
           var version:String? = null
            try {
                val manager = activity.packageManager
                val  info = manager.getPackageInfo(activity.packageName, 0)
                 version ="${info.versionCode}"

            } catch (e:Exception) {

            }
            return version!!.toInt()
        }



    }

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

调用检查：如果服务端返回的版本号大于当前的，调用下载。

```Kotlin
if(msg.arg1 >  Utils.getVersion(this@WDMain)){
                        Utils.Tos("新版本")

                            temDialog = AlertDialog.Builder(this@WDMain).setCancelable(false)
                                    .setTitle("检测到新版本！").setMessage("是否立即更新?")
                                    .setPositiveButton("确定"){
                                        _,_ ->
                                        Utils.DownNew()//下载更新
                                        Utils.Tos("请稍后查看通知栏进度！")

                                    }.setNegativeButton("取消"){
                                        _,_ ->
                                    }.create()
                            temDialog!!.show()
                        } else{
                        Utils.Tos("当前是最新版本")
                    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
