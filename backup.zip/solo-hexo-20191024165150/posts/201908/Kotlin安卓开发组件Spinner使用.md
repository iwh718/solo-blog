title: Kotlin安卓开发：组件Spinner使用
date: '2019-08-20 22:51:31'
updated: '2019-08-20 22:51:31'
tags: [android]
permalink: /articles/2019/08/20/1566312691491.html
---
本来是用得radioGroup，结果太多了，占地方，就改为了spinner。

![](https://img-blog.csdnimg.cn/2018122122321384.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

xml：这里有一个弹出模式，一个是pop的一个是下拉。

```html
       <Spinner
           android:id="@+id/sortSpinner"
           android:layout_width="wrap_content"
           android:layout_height="wrap_content"
           android:spinnerMode="dropdown">

        </Spinner>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

kotlin：

```Kotlin
  val searchSortSpinner = findViewById<Spinner>(R.id.sortSpinner)//获取spinner 
  val searchSortSpinnerData = arrayOf("正题名","出版日期","作者","出版社","索取号")
  searchSortSpinner.adapter = searchSortSpinnerAdapter//适配器
  searchSortSpinner.onItemSelectedListener = object:AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position:        Int, id: Long) {
                //切换选择
                searchSort = searchSortSpinnerData[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                
                searchSort = searchSortSpinnerData[0]
            }
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

spinner设置监听器不能向listview和其它的组件一样直接使用lambda简化

这里有的监听器目前还不支持，大部分监听接口是可以直接使用的。

这里用的是**kotlin的对象表达式：java中的匿名内部类。**

看看那些支持简化的监听器写法：直接用lambda代替对象表达式

```Kotlin
fab.setOnClickListener { _ ->
    //这个监听器有一个抽象方法未实现，可以使用lambda，lambda可以用在只有一个抽象方法的接口上

}
//spinner有多个，，，
listView?.onItemClickListener = AdapterView.OnItemClickListener {
_,_,position,_->


}
//listview
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
