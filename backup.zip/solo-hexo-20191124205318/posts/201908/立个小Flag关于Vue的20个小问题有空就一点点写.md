title: 立个小Flag：关于Vue的20个小问题，有空就一点点写。
date: '2019-08-25 11:23:28'
updated: '2019-10-10 16:32:29'
tags: [Vue]
permalink: /articles/2019/08/25/1566703408311.html
---
https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=745008878,2424441072&fm=26&gp=0.jpg
1、说下Vue数据双向绑定的原理  
  
2、说说Vuex的作用以及应用场景  
  
3、说说Vue组件的数据通信方式  

父->子：传输数据使用Props，调用子组件使用$refs
子->父：父组件使用on监听子组件上的xx方法，子组件方法调用$emit('xx')触发。
跨组件：vuex...
  
4、Vue的源码有看过吗？说说vuex工作原理  
  
5、为什么说虚拟 dom会提高性能，解释一下它的工作原理  

```
在渲染到真实节点前会通过DomDiff算法进行比对，再渲染。
```
  
6、请你详细介绍一些 package.json 里面的配置  
  
7、为什么说Vue是一套渐进式框架  
  
8、vue-cli提供的几种脚手架模板有哪些，区别是什么  
```
* webpack-具有热重载，整理，测试和CSS提取功能的全功能Webpack + vue-loader设置。
    
* webpack-simple-简单的Webpack + vue-loader设置，用于快速原型制作。
    
* browserify-全功能Browserify + vueify设置用热重装载，掉毛＆单元测试。
    
* browserify-simple-用于快速原型制作的简单Browserify + vueify设置。
    
* pwa-基于webpack模板的vue-cli的PWA模板
    
* simple-在单个HTML文件中最简单的Vue设置
```
  
9、计算属性的缓存和方法调用的区别  

```
计算属性会将不变的属性缓存（该属性依赖其他普通属性，如data里面的），如果该属性所依赖的属性多次被调用，但是没有进行数据操作，该方法不会被执行，而方法调用，每次都执行。
```
  
10、axios、fetch与ajax有什么区别  
```
ajax是异步请求技术，axios是对该接口的封装，并且支持Promise。
fetch是与ajax平级，ES6用来替换原生ajax的新方法，支持Promise。
```
  
11、vue中央事件总线的使用  
  
12、你做过的Vue项目有哪些，用到了哪些核心知识点  
  
13、实现MVVM的思路分析  
```
View Model 处理 View 与 Model交互，View发出事件，ViewModel来执行并且将Model更新到View上。
```
  
14、批量异步更新策略及 nextTick 原理  
  
15、说说Vue开发命令 npm run dev 输入后的执行过程  
  
16、vue-cli中常用到的加载器有哪些  
```
sass-loadersass-loader，Vue-loader，Less-loader
```
  
17、Vue中如何利用 keep-alive 标签实现某个组件缓存功能  
  
18、pc端页面刷新时如何实现vuex缓存  
  
19、vue-router如何响应 路由参数 的变化  
  
20、Vue 组件中 data 为什么必须是函数

```
如果data是普通的对象，当组件复用的时候，data被多个引用，会影响不同组件的数据，而函数返回，不仅可以通过作用域隔离，而且函数被多次调用与引用都是返回新的。
```


