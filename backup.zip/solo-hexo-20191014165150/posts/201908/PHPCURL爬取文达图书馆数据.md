title: PHP CURL爬取文达图书馆数据
date: '2019-08-19 22:11:59'
updated: '2019-08-19 22:11:59'
tags: [PHP, 爬虫]
permalink: /articles/2019/08/19/1566223919275.html
---
    博主的学校啦啦，是那种比较传统的网站，手机端打开简直不能看，验证码也会挡住（不过还好，via浏览器这个强制缩放能够输入验证码了），经常去图书馆借书，一般都是在电脑上查好借阅号再去找书，嘿嘿，不麻烦管理员小姐姐！

刚好最近在学PHP，PHP真是世界是最好的语言（我直接买了一本二手函数手册不离身），发现有一个curl库可以爬数据，开心，就去琢磨了一下。

先看一下，查询在哪。

![](https://img-blog.csdn.net/20180512224049122?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

在这个地方看看代码：

```html
<img src="http://172.16.1.43/images/nav5_1.gif" alt="馆藏检索" name="search" id="search" width="170" border="0" height="48">
```

注意用的内网地址！（以前可以外网的，不知道怎么了，总是连接失败了，无奈，我也不会内网穿透弄代理，所以第一个爬虫就凉了，没法放到ecs上，正在学习中，希望能解决这件事）

看一下查询表单

![](https://img-blog.csdn.net/20180512224439321?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

代码：tmj.asp是提交的地址，我模拟的是图书名和条数，其他默认。

```html
<form action="tmjs.asp" name="frmTmjs" method="POST" language="javascript" onsubmit="return frmTmjs_onsubmit()" onreset="return frmTmjs_onreset()">
<table align="center" width="90%" cellspacing="0" cellpadding="0" border="0">
	<tbody><tr>
		<td class="tdborder1a" align="right"> 文献类型：</td>
		<td class="tdborder2a">
		<input id="txtWxlx" name="txtWxlx" value="CN" checked="" onclick="changeLx('spanCNLx')" type="radio">中文图书 
		<input id="txtWxlx" name="txtWxlx" value="EN" onclick="changeLx('spanENLx')" type="radio">西文图书
		<!-- 
		<INPUT type="radio" id=txtWxlx  name=txtWxlx value="YX"   onclick="changeLx('spanCNLx')">音像资料		
		-->
		<input id="hidWxlx" name="hidWxlx" value="spanCNLx" type="hidden"><!-- 这个参数，是用在div的。-->
		</td>
	</tr>
	<tr>
		<td class="tdborder3" align="right"> 检索方式：</td>
		<td class="tdborder4">
		<input id="txtPY" name="txtPY" value="HZ" checked="" type="radio">题名 
		<input id="txtPY" name="txtPY" value="PY" type="radio">题名拼音头
		</td>
	</tr>

	<tr>
		<td class="tdborder3" align="right">检索词： </td>
		<td class="tdborder4"><input name="txtTm" id="txtTm" type="text"></td>
	</tr>
	<tr>
		<td class="tdborder3" align="right">题名类型：</td>
		<td class="tdborder4">
<span id="spanLx">

			<select size="1" name="txtLx">
			<option value="%">XXX 检索所有题名</option>
			<option value="200">200 正题名</option>
			<option value="4＃＃">4## 丛编总集题名</option>
			<option value="4XX">4XX 所有相关题名</option>
			<option value="500">500 统一题名</option>
			<option value="510">510 并列正题名</option>
			<option value="512">512 封面题名</option>
			<option value="513">513 附加题名页名</option>
			<option value="514">514 卷端题名</option>
			<option value="515">515 逐页题名</option>
			<option value="516">516 书脊题名</option>
			<option value="517">517 其它题名</option>			
			<option value="545">545 章节题名</option>
			</select>

</span>

		</td>
	</tr>
	<tr>
		<td class="tdborder3" align="right"> 检索方式：</td>
		<td class="tdborder4">		
			<select size="1" name="txtSearchType">
			<option selected="" value="1">前方一致</option>
			<option value="2">模糊查询</option>
			<option value="3">精确查询</option>
			</select>
		</td>
	</tr>
	
	<tr>
		<td class="tdborder3" align="right">最大记录数：</td>
		<td class="tdborder4">
			<select size="1" name="nMaxCount">
				<option value="100" selected=""> 100 </option>
				<option value="300"> 300 </option>
				<option value="500"> 500 </option>
				<option value="1000"> 1000 </option>
				<option value="3000"> 3000 </option>
				<option value="5000"> 5000 </option>
				<option value="0"> 全部记录 </option>
			</select>
		</td>
	</tr>
	<tr>
		<td class="tdborder3" align="right">页显示记录数：</td>
		<td class="tdborder4">
			<select size="1" name="nSetPageSize">
				<option selected="" value="10"> 10 </option>
				<option value="20"> 20 </option>
				<option value="50"> 50 </option>
				<option value="100"> 100 </option>
			</select>
		</td>
	</tr>
	<tr>
		<td class="tdborder3" align="right">结果排序顺序：</td>
		<td class="tdborder4">
			<select name="cSortFld">
				<option selected="" value="正题名">正题名 </option>
                <option value="出版日期"> 出版日期 </option>				
                <option value="索取号">索取号</option>
				<option value="责任者">责任者</option>
				<option value="出版者">出版者 </option>
			</select>
		</td>
	</tr>

	<tr>
		<td colspan="2" class="tdborder3" align="center">
			<input value="检 索" name="B1" class="buttonface" type="submit">
			      
			<input class="buttonface" value="重 写" name="B12" type="reset">
		</td>		
	</tr>
</tbody></table>
</form>
```

  

这里我就只自定义两个参数提交了，其他同理！

![](https://img-blog.csdn.net/2018051222571318?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

bt写的界面就不贴代码了。

下面是模拟提交：

```html
<!DOCTYPE html>
<html>
<head>
    <title>图书</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    
    <link href="./css/bootstrap.css" rel="stylesheet">
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/jquery-3.1.0.min.js"></script>
    <style type="text/css">
    td:nth-child(1){display: none;}/**去除多余td因为正则刚学处理的不好**/
    td:nth-child(3){display: none;}
    td:nth-child(5){display: none;}
    </style>
</head>
<body>
    <?php  
        header("Content-type:text/html;charset=utf-8");  
        
   
        $_cx=urlencode($_POST['_cx_f']);//获取传入书籍名称
        $_page=$_POST['_page'];//获取设置最大条数
       
        $data="page=1&txtWxlx=CN&txtTm=".$_cx."&txtLx=%25&txtSearchType=1&nMaxCount=100&nSetPageSize=".$_page."&txtPy=HZ&cSortFld=%E6%AD%A3%E9%A2%98%E5%90%8D";//模拟post数据
        //$data构造数据，其中有_cx用的url编码
        $curl="http://172.16.1.43/wxjs/tmjs.asp";//初始化curl
        $ch= curl_init ();  //初始化curl  
        curl_setopt($ch, CURLOPT_URL, $curl);//要从哪个页面获取信息
     
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);//传递数据
        curl_setopt($ch,CURLOPT_POST,1);//提交方式
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5');//模拟浏览器
         //模拟浏览器
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//设定返回 的数据是否自动显示
        curl_setopt($ch, CURLOPT_HEADER, 0);//设定是否显示头信息

        $content = curl_exec($ch);//运行并获取数据
        curl_close($ch);//关闭请求
        $str1=preg_replace("/<a[^>]+?href=[\"']?([^\"']+)[\"']?[^>]*>/","",$content );//perl正则表达式去除a标签
        $pattern="/<td class=\"tdborder4\".*?>.*?<\/td>/ism";//perl模式
        preg_match_all($pattern, $str1, $n);//按照模式获取数据并传回数组$n
        $arr_tmp=$n[0];//取出数组
        $_books=array_chunk($arr_tmp,6);//二维数组分割，重新分配下标
        //print_r($_books);//打印数组数据  
    ?>  
    <table class="table table-striped table-bordered table-hover"><!--bt框架表格-->
        <thead>
            <tr>
                <th>图书编号</th>
                <th>书籍名称</th>
                <th>出版日期</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            
            foreach ($_books as $key=>$value) //循环输出
            {
                
                echo "<tr>";
                echo "<td class=\"_title\">"."$value[0]"."</td>";
                echo "<td class=\"_title\">"."$value[1]"."</td>";
                echo "<td class=\"_title\">"."$value[4]"."</td>";
                echo "</tr>";
            }

            ?>
        </tbody>
    </table>
</body>
</html>

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

  

  

print_r($n)

二维数组，把[0]取出来，每个图书有六个信息，chunk()函数分

![](https://img-blog.csdn.net/20180512230354311?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
