title: PHP 获取青果教务的验证码与登录，成绩查询
date: '2019-08-20 07:25:52'
updated: '2019-08-20 07:25:52'
tags: [PHP, 教务系统]
permalink: /articles/2019/08/20/1566257152683.html
---
目前已经完成文达学院青果教务登录（其它学校请去下方链接GitHub获取项目，自行修改），一键获取成绩单，成绩查询是图片的同学，这里使用的是成绩分布的接口，这个接口一般是表格数据，查询结果顺便加个挂科检测。

项目地址：[青果一键查成绩](https://github.com/iwh718/QingGuoWD),记得点个星星哦，谢谢。

demo截图：

![](https://img-blog.csdnimg.cn/20190325132710230.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20190325132815915.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

---

  

分割线：代码已经修改很多，下方仅作为参考，具体看GitHub。

注意：有同学会发现登录后返回出现系统错误等，可能是：

1.viewState有问题。

2.不要echo 输出返回的数据

3.将返回的数据存储到文件里，检查一下，是否登录完成，因为，登陆完成js会重定向页面，如果出现这段代码，就是登录完成，然后，我们就可以继续用之前的cookie去获取成绩。

如果之前你直接输出返回的数据，由于路径的原因，js重定向肯定错误页。检查登录可以用正则匹配一下，获取打开文件看看。

项目中有一个 HSDM 这是一个PHP DOM库，很好用，之前一直用正则写，这个库很方便，直接读取保存的文件。

  

---

思路就是用户访问我的index，然后在验证码更新的时候，请求的另一个getValidate.php，这个请求先载入青果首页一次，获取viewstate的值还有session与cookie。

接下来利用cookie去请求青果验证码。返回给index.php

看看index.php（目前登录没成功，验证实现了，还有js的加密）

没有做美化，这大部分是青果的源代码。

```html
                //这里有一个md5的js，直接把青果首页的拿下来，还有下面的js加密函数都是青果页面获取的
		 <script type="text/javascript" src="./md5.js"></script>
		<script type="text/javascript">

                 function showvc()
		     {
			$("#imgCode").style.display = "";
		    }

                window.onload=function(){
	            //载入页面，首先把验证码获取一下
                    try{$('txt_asmcdefsddsd').focus();}catch(err){}
                    try{$('typeName').value=$N('Sel_Type')[0].options[$N('Sel_Type')
                    [0].selectedIndex].text;}catch(err){}
                    }
                //改变验证码，注意这里是我们写的php文件

                function changeValidateCode(Obj){
                var dt = new Date();
                Obj.src="./getValidate.php?t="+dt.getMilliseconds();
                }
                function chkpwd(obj) {  if(obj.value!='')  {    var         s=md5(document.all.txt_asmcdefsddsd.value+md5(obj.value).substring(0,30).toUpperCase()+'12810').substring(0,30).toUpperCase();   document.all.dsdsdsdsdxcxdfgfg.value=s;} else { document.all.dsdsdsdsdxcxdfgfg.value=obj.value;} }  function chkyzm(obj) {  if(obj.value!='') {   var s=md5(md5(obj.value.toUpperCase()).substring(0,30).toUpperCase()+'12810').substring(0,30).toUpperCase();   document.all.fgfggfdgtyuuyyuuckjg.value=s;} else {    document.all.fgfggfdgtyuuyyuuckjg.value=obj.value.toUpperCase();}}
</script>
	</head>
	
	<body style="background-color:#469B79" >
		
	
		<form name="Logon" method="post" action="./login.php" id="Logon"  autocomplete="off">
	    <input name="__VIEWSTATE" value="" type="hidden">
	    <input id="pcInfo" name="pcInfo" value="Mozilla/5.0 (Windows NT 10.0; WOW64; rv:63.0) Gecko/20100101 Firefox/63.0Windows NT 10.0; WOW645.0 (Windows) SN:NULL" type="hidden">
		<input id="typeName" name="typeName" value="学生" type="hidden" class="form-control">
		<input id="dsdsdsdsdxcxdfgfg" name="dsdsdsdsdxcxdfgfg" type="hidden">
		<input id="fgfggfdgtyuuyyuuckjg" name="fgfggfdgtyuuyyuuckjg" type="hidden">	
					
		<div id="UID" style="color:white;" width="50" height="26" align="center">学　号</div>
		<div><input name="txt_asmcdefsddsd" id="txt_asmcdefsddsd" class="form-control"  type="text">
		</div>
		
		
		<div id="PWD" style="color:white;" width="50" nowrap="" height="26" align="center">密　码</div>
		<div width="120" valign="top" height="26">
		<input class="form-control" id="txt_pewerwedsdfsdff"  name="txt_pewerwedsdfsdff"  onblur="chkpwd(this)" onkeyup="chkpwd(this)" type="password">
		</div>						
	
		<div style="color:white;" width="50" height="26" align="center">验证码</div>
		<div height="26">
		<input class="form-control" id="txt_sdertfgsadscxcadsads" name="txt_sdertfgsadscxcadsads"  onblur="chkyzm(this)" onkeyup="chkyzm(this)">
		<img id="imgCode" src="./getValidate.php" onclick="changeValidateCode(this)" alt="单击可更换图片！" style="WIDTH:80px;HEIGHT:20px;CURSOR:pointer;margin:0px;">						
		</div>
															
		<button class="btn btn-primary" type="submit">登录</button>
					
								
			
		</form>		
	
				
</body></html>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后看看，点击验证码的时候，我们后面干了啥。

```php
<?php
//先访问青果首页获取viewstate与session
$ch1 = curl_init();
$header[]="User-Agent:Mozilla/5.0 (Windows NT 6.1; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0";
$header[]="Cache-Control: max-age=0";   
$header[]="Connection: keep-alive";
$header[]="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"; 
$header[]="Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3";
$header[]="Host:218.22.58.76:2346";    
curl_setopt($ch1,CURLOPT_HTTPHEADER,$header);
curl_setopt($ch1, CURLOPT_URL, "http://218.22.58.76:2346/_data/home_login.aspx");
curl_setopt($ch1,CURLOPT_VERBOSE,1);
curl_setopt($ch1, CURLOPT_HEADER,true);
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_jar);
$filecontent=curl_exec($ch1);
//echo $filecontent;
preg_match('/Set-Cookie:(.*);/iU',$filecontent,$str); //正则匹配
$cookie = $str[1]; //获得COOKIE（SESSIONID）
$_SESSION['cookie']=$cookie;
preg_match('/<input type=\"hidden\" name=\"__VIEWSTATE\" value=\"(.*)\"/iU',$filecontent,$str);
$__VIEWSTATE=$str[1];

$_SESSION['__VIEWSTATE']=$str[1];
//保存好viewstate，一会要在登录处用
//echo $_SESSION['__VIEWSTATE'];



$cookie = $_SESSION['cookie'];

$t = isset($_GET['t'])?$_GET['t']:0;
$verify_code_url = "http://218.22.58.76:2346/sys/ValidateCode.aspx?t=".$t;
$header = [
    'Accept:image/webp,image/apng,image/*,*/*;q=0.8',
    'Accept-Encoding:gzip, deflate',
    'Accept-Language:zh-CN,zh;q=0.8',
    'Cache-Control:no-cache',
    'Connection:keep-alive',
    'Host:j218.22.58.76:2346',  //修改名称
    'Pragma:no-cache',
    'Referer:http://218.22.58.76:2346/_data/home_login.aspx',//修改名称
    'User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64; rv:63.0) Gecko/20100101 Firefox/63.0Windows NT 10.0; WOW645.0 (Windows) SN:NULL',
];

$curl = curl_init();
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);  //设置表头
curl_setopt($curl, CURLOPT_URL, $verify_code_url); // 设置请求地址
curl_setopt($curl,CURLOPT_COOKIEJAR,$cookie); //获取COOKIE并存储

$img = curl_exec($curl);
curl_close($curl);

//返回验证码图片
echo $img;



?>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

现在验证码就可以随时刷新了。目前这个viewstate还没解决好。解决了，再看看登录。。。

现在去post登录出现viewstate无效。。正在琢磨。

![](https://img-blog.csdnimg.cn/20181028121640450.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_27,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

![](https://img-blog.csdnimg.cn/20181028121514589.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_27,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

 后来解决登录的原因就是在于时间差！青果会检查时间差判断是爬虫。

后来用得是：

在index.php头部访问青果首页，拿到viewstate与cookie，并且把cookie存储到session

在点击验证码的时候，带上cookie与viewstate直接访问登录页面。

然后，出现重定向就ok了。看见sorry页面的基本是验证码和viewstate的问题。
