title: kotlin安卓：每天一个组件 常用对话框
date: '2019-08-20 07:19:03'
updated: '2019-08-20 07:19:03'
tags: [kotlin, android]
permalink: /articles/2019/08/20/1566256743041.html
---
今天用到的是对话框（前排提示，导包时候注意，是原生包，不是V7的本文）

看看所有的按钮：![](https://img-blog.csdn.net/20181016193052446?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

这里放一个代码循环设置监听器：

```Kotlin
        val dia_1 = findViewById<Button>(R.id.btn_dia1)        
        val dia_2 = findViewById<Button>(R.id.btn_dia2)
        val dia_3 = findViewById<Button>(R.id.btn_dia3)
        val dia_4 = findViewById<Button>(R.id.btn_dia4)
        val dia_5 = findViewById<Button>(R.id.btn_dia5)
        val dia_6 = findViewById<Button>(R.id.btn_dia6)
        val arr_btn = arrayOf<Button>(dia_1,dia_2,dia_3,dia_4,dia_5,dia_6)
        for(i in arr_btn.indices){
            arr_btn[i].setOnClickListener{
                startBtn(i+1)//注意下标是0开始的，后面用得是when从1开始
            }
        }
         when(n){
            1 -> {
             
               
            }
            ·····
            }
            6 -> {
                val dialog = AlertDialog.Builder(this@Main9Activity)
                dialog.setTitle("这是简单列表").setItems(items){
                    _,which ->
                    tips("你点击的是：${items[which]}")
                }.create().show()
            }

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

首先说一下步骤：

一个按钮或者事件，启动对话框，对话框创建步骤如下：

1.通过AlertDialog.Builder(this)构造一个dialog对象。

2.通过dialog的方法设置属性，下面会具体介绍。

3.然后用create()方法生成，最后和Toast一样用show()调出啦。

kotlin可以用点语法直接设置属性，下面是最简单的一个对话框。

@1那传入一个lambda表达式

setNegativeButton("文”,{dialog,which -> xxx}),简化以后移到后面了

这里_和_是说明后面用不到这个参数

全文用了一个数组items是一个字符串数组，和一个封装的Toast方法tips（tip：String），略了哈

```Kotlin
 var dialog = AlertDialog.Builder(this@Main9Activity)
                .setTitle("这是简单对话框！")
                 //这里说一下，设置取消按钮，这里传入一个lambda表达式@1
                .setNegativeButton("cancel"){
                    _,_ ->
                    tips("取消:简单对话框")}
                 //设置内容文本
                .setMessage("这是简短的内容").create().show()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

效果图：

![](https://img-blog.csdn.net/20181016191345443?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

接下来开始看看背的对话框：

列表对话框：

```Kotlin
val items = arrayOf("1123","123234","11313")   
val dialog = AlertDialog.Builder(this@Main9Activity)
                dialog.setTitle("这是简单列表").setItems(items){
                    _,which ->
                    tips("你点击的是：${items[which]}")
                }.create().show()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

预览图片：这里可以利用which获取数组下标，去做其他的事情。

![](https://img-blog.csdn.net/20181016193432959?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

接下来是单选对话框：代码里items右面的参数是设置第几个为默认选中。

```Kotlin
 val dialog1 = AlertDialog.Builder(this@Main9Activity)
                dialog1.setSingleChoiceItems(items,1){
                    dialog, which ->
                    val text = "你选中的是${items[which]}"
                    tips(text)

                }.create().show()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

预览：单选图找不到了，用多选图吧，区别就是前面的选择图标

![](https://img-blog.csdn.net/20181016193653102?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

下面是多选代码：参数，数组，整形的boolean代表，默认哪个选中。，最后是根视图。

```Kotlin
 val dialog = AlertDialog.Builder(this@Main9Activity)
                dialog.setMultiChoiceItems(items,booleanArrayOf(true,false,true),null)
                        .create().show()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

下面上经常自定义用得两个：

首先是adapter对话框：这里可以传入一个adapter，现在用得是arrayadapter可以用simpleadapter

```Kotlin
 val dialog = AlertDialog.Builder(this@Main9Activity)
               dialog.setTitle("我是自定义对话框")
                       .setAdapter(ArrayAdapter(this@Main9Activity,R.layout.array_list,items),null)
                       .create().show()
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

预览：没有弄样式，看代码就知道啦、

![](https://img-blog.csdn.net/2018101619400828?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

最后是很强大的自定义View对话框：首先引入一个布局文件，然后用setView（）设置。如果想获取lay内部控件，首先获取lay对象，用findViewById就好啦。

```Kotlin
 val lay = layoutInflater.inflate(R.layout.login,null)

                val dialog = AlertDialog.Builder(this@Main9Activity)
                dialog.setTitle("这是自定义view")
                        .setView(lay).create().show()
                lay.findViewById<Button>(R.id.login_ok).setOnClickListener{
                    tips("你点击了确定")
                }
                lay.findViewById<Button>(R.id.login_cancel).setOnClickListener{
                    tips("你点击了取消")
                }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

  

预览：好了，常用对话框，用kotlin方式写完了。

![](https://img-blog.csdn.net/20181016194226458?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​
