title: Kotlin获取组件对象的泛型方法
date: '2019-08-19 22:16:51'
updated: '2019-08-19 22:16:51'
tags: [kotlin]
permalink: /articles/2019/08/19/1566224211353.html
---
刚接触kotlin记一下：

findViewById()这个方法用来获取组件对象

第一种普通的：

```Kotlin
//button id为 btn_1

...mian(){

    private var btn:Button?=null //kotlin防止出现空指针用了？

    onCreate(...){

        btn=findViewById(R.id.btn_1)  //这里btn已经是一个Button对象的实例

        }

    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

第二种泛型使用：

```Kotlin
//直接获取实例

var btn=findViewById<Button>(R.id.btn_1)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

补充第三种：

```

var lay=findViewById(R.layout.xx) as LinearLayout
//强制向上转型
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

之前看书的时候泛型也没什么感觉，现在觉得，真好。

看的资料大都是与java有关，我没有java背景，熟悉的只有PHP与JS，还有一点c++，主要是C++啊，很多语言都有他的影子，尤其kotlin的语法使用方面。不过遗憾的是kotlin的资料远远不如java。不然IDE出错，都很麻烦。
