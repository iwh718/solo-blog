title: android P（9.0）设备数据库导入，查询为空的问题。
date: '2019-08-20 23:05:22'
updated: '2019-08-20 23:05:22'
tags: [android]
permalink: /articles/2019/08/20/1566313522198.html
---
原先数据库在android9.0设备下是正常使用的。

在assets中内置一个数据库，程序初始化时，初始化数据库，并导入该数据库。

但是在android9.0上默认使用了SQLite的新版特性：WAL模式。

具体请百度，大概就是，数据没有直接被导入数据库，中间需要一些流程。

db.disableWriteAheadLogging()

放到数据库help：onCreate中就好了。
