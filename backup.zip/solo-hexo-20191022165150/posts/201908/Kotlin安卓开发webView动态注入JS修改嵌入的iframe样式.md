title: Kotlin安卓开发：webView动态注入JS修改嵌入的iframe样式
date: '2019-08-20 07:18:25'
updated: '2019-08-20 07:18:25'
tags: [kotlin, android]
permalink: /articles/2019/08/20/1566256705864.html
---
 

```Kotlin


val web_wd = findViewById<WebView>(R.id.web_wd)

//获取 webview对象

var web_set = web_wd.settings
//获取webviewset对象

web_set.javaScriptEnabled=true
//设置允许JS，会提示xss危险

web_wd.webViewClient=object:WebViewClient(){
//利用对象表达式实现匿名内部类，并重写方法

    override fun onPageFinished(view: WebView?, url: String?) {
    super.onPageFinished(view, url)
    //页面加载结束调用

    //开始载入指定URl，我们要注入的URL的JS，可以分步注入JS
    web_wd.loadUrl("javascript:document.querySelecto·······;" )
    web_wd.loadUrl("javascript: iframe_box.contentWindow.document.querySelector('body form table tr td table tbody tr td:nth-of-type(2) select').setAttribute('style','width:80%');" +
" iframe_box.contentWindow.document.querySelector('body form table tr td table tbody tr td:nth-of-type(1)').setAttribute('style','width:20%');")}

//这里注入了iframe用到一个前端的代码：iframe对象.contentWindow.document.querySelector('xxx')这样就可以获取iframe里面的元素了
}
//页面加载结束以后，加载指定页面，即要注入的URl
web_wd.loadUrl("http://xxxxxx/")

}

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
