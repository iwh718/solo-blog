title: android MenuItem item的getactionView方法提示is deprecated 解决办法
date: '2019-08-19 22:17:25'
updated: '2019-08-19 22:17:25'
tags: [android]
permalink: /articles/2019/08/19/1566224245877.html
---
这里用的是Kotlin语言写的。

因为在android的api：26上这个方法被改了！

原先写法：

```Kotlin
override fun onCreateOptionsMenu(menu: Menu): Boolean {

          getMenuInflater().inflate(R.menu.activity_wd_main_drawer, menu)
           var nav_my_item = menu.findItem(R.id.nav_my)
           var nav_item_view= MenuItemCompat.getActionView(nav_my_item);

        return super.onCreateOptionsMenu(menu)
    }

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 api更改以后：

```Kotlin
verride fun onCreateOptionsMenu(menu: Menu): Boolean {

          getMenuInflater().inflate(R.menu.activity_wd_main_drawer, menu)
           var nav_my_item = menu.findItem(R.id.nav_my)
            var nav_my_view= nav_my_item.getActionView()

        return super.onCreateOptionsMenu(menu)
    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
