title: kotlin安卓开发：fragment向activity传递数据通过handler，设置回调方法
date: '2019-08-20 22:49:48'
updated: '2019-08-20 22:49:48'
tags: [android]
permalink: /articles/2019/08/20/1566312588653.html
---
从activity向fragment传递就比较方便了，直接用：

```Kotlin
 fg.arguments = arguments
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

现在看看怎么从fragment向activity传递数据。

比如说，我们在一个ViewPage里面设置了若干个fragment，fragment里面有一个按钮，提交相关当前fg下标给viewPage所在的activity，删除当前的fg。

这里使用了handler，提交完信息，activity就立即更新UI

首先我们在fg中写一个接口

```Kotlin
interface Callbacks{

        fun onRemove(position:Int){

        }
    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

让我们的activity实现该接口：如果未实现，则抛出异常，这里在fg中有一个attach方法，是载入fg时候自动调用的。

```Kotlin
override fun onAttach(context: Context?) {
        if(context !is Callbacks){
            throw IllegalStateException("接口未实现")
        }
        super.onAttach(context)
        mcallbacks = context

    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后我们在给fg的按钮添加监听器，调用该方法。

```Kotlin
  mcallbacks!!.onRemove(position)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

  

现在是空的方法。

我们在activity给它实现以下：

 这里我们看到接收来自fg的下标。

这里接收fg传过来的下标。

在主活动的handler可以接收下标

```Kotlin
//主活动继承接口，实现回调方法
    override fun onRemove(position:Int) {

        val msg  = Message()
        msg.what = 1
        msg.arg1 = position
        handle?.sendMessage(msg)
        Log.d("callback:",msg.what.toString())

    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 看看主活动的handler：接收是msg.what的值。

```Kotlin
 ···1->{

                        list_fg.removeAt(msg.arg1)
                        Log.d("msg:",msg.arg1.toString())
                        iwh_view_page_adapter.notifyDataSetChanged()
                    }···
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

 接收到下标后，通知适配器更新。
