title: Kotlin：使用Application类获取全局Context
date: '2019-08-20 22:51:49'
updated: '2019-08-20 22:51:49'
tags: [android]
permalink: /articles/2019/08/20/1566312709774.html
---
今天碰到一个群友说起application类，想着用kotlin写一下。

kotlin没有static类型，只能用伴生对象了。

很简洁：以后就可以直接在任意的类里面使用WdTools.getContext()获取Context对象了。

```Kotlin
class WdTools:Application(){
    companion object {
        var  _context:Application? = null
        fun getContext():Context{
            return _context!!
        }

    }

    override fun onCreate() {
        super.onCreate()
        _context = this
    }



}
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

最后别忘记在manifest注册：ok。

```html
<application
        android:name=".WdTools"
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
