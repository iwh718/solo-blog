title: PHP用CURL爬学校妙思文献图书馆（个人学习日志）
date: '2019-08-19 22:12:37'
updated: '2019-08-19 22:12:37'
tags: [PHP, CURL]
permalink: /articles/2019/08/19/1566223957059.html
---
    记录一下，刚学习PHP看到有人用CURL爬数据，就想着怎么做个爬学校图书馆的，学校的网页没有适配移动端很麻烦，每次都只能用电脑查借阅号然后去图书馆找，很不爽，有时候抄错了，还要麻烦图书馆小姐姐诶！

tips：本文curl函数借鉴了csdn以及其他论坛的资料，感谢.

下图是部分截图：

![](https://img-blog.csdn.net/20180512232046970?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

图书馆表单参数很多，我用了俩自定义的其他都是默认,同理。

![](https://img-blog.csdn.net/20180512231752659?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​![](https://img-blog.csdn.net/2018051223185586?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​![](https://img-blog.csdn.net/20180512231907770?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

下面贴代码：

开始找到表单最终提交的地址：tmjs.asp（我用的内网地址）

```html
<!DOCTYPE html>
<html>
<head>
	<title>图书</title>
	<meta charset="utf-8">
	<meta name="viewport"xxxxxxxxxx,user-scalable=no">
	<link href="./css/bootstrap.css" rel="stylesheet">
	<script src="./js/bootstrap.min.js"></script>
	<script src="./js/jquery-3.1.0.min.js"></script>
	<style type="text/css">
	td:nth-child(1){display: none;}/**去除多余td，正则不会处理的不好**/
	td:nth-child(3){display: none;}
	td:nth-child(5){display: none;}
	</style>
</head>
<body>
	<?php  
        header("Content-type:text/html;charset=utf-8");  
        $_cx=urlencode($_POST['_cx_f']);//获取传入书籍名称
        $_page=$_POST['_page'];//获取设置最大条数
        $data="page=1&txtWxlx=CN&txtTm=".$_cx."&xxxxxxx";//模拟post构造数据_cx是书名用了url编码
        $curl="http://172.16.1.43/wxjs/tmjs.asp";//初始化curl模拟提交的地址（内网我用刀的）
        $ch= curl_init ();  //初始化curl 
        curl_setopt($ch, CURLOPT_URL, $curl);//要从哪个页面获取信息
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);//传递数据
        curl_setopt($ch,CURLOPT_POST,1);//提交方式post
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

```html
     curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NTxxxxxxxxx;//模拟浏览器
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//设定返回 的数据是否自动显示
     curl_setopt($ch, CURLOPT_HEADER, 0);//设定是否显示头信息
     $content = curl_exec($ch);//运行并获取数据
     curl_close($ch);//关闭请求
        $str1=preg_replace("/<a[^>]+?href=[\"']?([^\"']+)[\"']?[^>]*>/","",$content );//perl正则表达式去除a标签
        $pattern="/<td class=\"tdborder4\".*?>.*?<\/td>/ism";//perl模式
        preg_match_all($pattern, $str1, $n);//按照模式获取数据并传回数组$n
        //print_r($n);
        $arr_tmp=$n[0];//三维数组转二维
        $_books=array_chunk($arr_tmp,6);//二维数组分割，重新分配下标
        //print_r($_books);//打印数组数据  
	?>  
	<table class="table table-striped table-bordered table-hover"><!--bt框架表格-->
		<thead>
			<tr>
				<th>图书编号</th>
				<th>书籍名称</th>
				<th>出版日期</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			
			foreach ($_books as $key=>$value) //循环输出
			{
				
				echo "<tr>";
				echo "<td class=\"_title\">"."$value[0]"."</td>";//书名
				echo "<td class=\"_title\">"."$value[1]"."</td>";//借阅号
				echo "<td class=\"_title\">"."$value[4]"."</td>";//出版时间
				echo "</tr>";
			}

			?>
		</tbody>
	</table>
</body>
</html>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

  

  

  
  

  

结束，由于学校图书馆外网突然不能访问，嗯，凉了，没法放到ecs了，穿透又不会（要是有文达校友一起玩！）
