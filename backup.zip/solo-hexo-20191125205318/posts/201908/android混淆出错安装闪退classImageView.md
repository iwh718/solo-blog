title: android 混淆出错|安装闪退|class ImageView
date: '2019-08-20 22:55:25'
updated: '2019-08-20 22:55:25'
tags: [android]
permalink: /articles/2019/08/20/1566312925155.html
---
最近给APP更新了一个版本，还是按照往常的混淆，不知道怎么了，打包发布后，启动就是闪退。

后来，看到了日志有关于 ImageView报错的问题，也没注意怎么回事，更新就换个图片，这个部分，后来，把混淆打开了日志，看到了错误！

混淆了 V7的包和V4的包。

导致闪退。

下面是报错的部分代码。。。

  Caused by: android.view.InflateException: Binary XML file line #7: Binary XML file line #7: Error inflating

 Caused by: android.view.InflateException: Binary XML file line #7: Error inflating class ImageView  
     Caused by: java.lang.NullPointerException: Attempt to invoke virtual method 'void android.support.v7.widget.ap.d()' on a null object reference  
        at android.support.v7.widget.AppCompatImageView.setImageDrawable(AppCompatImageView.java:102)  
        at android.widget.ImageView.<init>(ImageView.java:159)  
        at android.widget.ImageView.<init>(ImageView.java:145)  
        at android.support.v7.widget.AppCompatImageView.<init>(AppCompatImageView.java:72)  
        at android.support.v7.widget.AppCompatImageView.<init>(AppCompatImageView.java:68)

 **混淆文件规则顺便学了点。。**

```Kotlin
#打开混淆日志
-verbose
# 不混淆泛型
-keepattributes Signature
# 不混淆第三方的包，如okhttp
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
#避免警告
-dontwarn okhttp3.** -keep class okio.** { *; }
-keep interface okio.** { *; }
-dontwarn okio.** -keep class com.hitomi.** { *; }
-keep interface com.hitomi.** { *; }
-dontwarn com.hitomi.**
-printmapping mapping.txt
# 对R文件下的所有类及其方法，都不能被混淆
-keepclassmembers class **.R$* {
    *;
}
# 不需要混淆android-support-v4.jar
-dontwarn android.support.v4.**
-keep class android.support.v4.** { *; }
-keep interface android.support.v4.app.** { *; }
-keep public class * extends android.support.v4.**
-keep public class * extends android.app.Fragment
-keepattributes *Annotation*
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.preference.Preference
-keep public class com.android.vending.licensing.ILicensingService
-keep class android.support.v7.** { *; }   
 #过滤android.support.v7 
-keep interface android.support.constraint.** { *; }






```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
