title: Kotlin安卓开发：监听锁屏与亮屏，推送通知
date: '2019-08-20 23:03:13'
updated: '2019-08-20 23:03:13'
tags: [android]
permalink: /articles/2019/08/20/1566313393159.html
---
前面说过写了个todo的应用：锁屏备忘录。肯定要监听锁屏的事件。

首先写个Service启动后创建一个广播接收器：监听系统的锁屏与亮屏事件，这个接收器写在service的OnCreate里。

```Kotlin
   mBroadcastReceiver = object:BroadcastReceiver(){

            override fun onReceive(context: Context?, intent: Intent?) {
            //开始写推送
              
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后service注册一下：priority是优先级。

```Kotlin
 this.registerReceiver(mBroadcastReceiver,IntentFilter(Intent.ACTION_SCREEN_ON).apply {
            priority = 1000
        })
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

记得在onDestory里取消

```Kotlin
  this.unregisterReceiver(mBroadcastReceiver)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

在intentFilter里面可以选择你需要接收的广播。示例是亮屏，然后就可以推送todo了。
