title: Kotlin安卓开发：notification通知的适配
date: '2019-08-20 23:03:36'
updated: '2019-08-20 23:03:36'
tags: [android]
permalink: /articles/2019/08/20/1566313416642.html
---
最近一直在学习Kotlin桌面端框架TornadoFx的使用，没怎么写笔记了，使用kotlin开发桌面应用很棒啊，有空一定写个记录，其中还有JavaFx的Jfoenix的Material设计的UI库在TornadoFx简直无缝使用。哈哈。

进入正题，在社区看到有人说有没有锁屏备忘录的应用，就花点时间写了个android的。

然后遇到了：android8.0的通知适配，主要是通知的通道与分组，前者控制在高版本设备上是否显示通知，后者控制如果来自一个应用超过三个通知，会折叠，我们要把这个折叠禁止，最后就是如何保持Service一直不被后台清理。

首先我们先创建一个通知管理：判断版本记得，低版本的设备不需要channelId，这是新版本的规定，必须设置通道ID，这里我设置了三个不同的Id，为了后面不被折叠。

```Kotlin
  mNm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            mNm.createNotificationChannels(listOf(  NotificationChannel(
                "lockTodo1",
                "Todo1",
                NotificationManager.IMPORTANCE_HIGH
            ),  NotificationChannel(
                "lockTodo2",
                "Todo2",
                NotificationManager.IMPORTANCE_HIGH
            ),  NotificationChannel(
                "lockTodo3",
                "Todo3",
                NotificationManager.IMPORTANCE_HIGH
            ),  NotificationChannel(
                "notifyTodo",
                "TodoTop",
                NotificationManager.IMPORTANCE_HIGH
            )))
        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后我们创建一个通知看看：注意看setGroupSummary我们设置为False就不会折叠了。

设置显示等级：visibility这里可以设置是否锁屏显示。

```java
   val notifyBuild = NotificationCompat.Builder(this@LightService, "lockTodo${i.key}")
                                        //设置通知标题
                                        .setContentTitle("${todoList["${i.key.toInt() - 1 }"]?:"默认todo"}")
                                        //设置通知内容
                                       // .setContentText("请继续保持哦！")
                                        .setAutoCancel(true)
                                        .setGroup("todos")
                                        .setGroupSummary(false)
                                        .setContentIntent(pi)
                                        .setLargeIcon(BitmapFactory.decodeResource(context?.resources,R.drawable.notify))
                                        .setSmallIcon(R.drawable.launch)
                                        .setShowWhen(true).build().apply {
                                            visibility = Notification.VISIBILITY_PUBLIC
                                        }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后我们发出这个通知：第一个是通知id和通道id不一样的注意！

```Kotlin
 mNm.notify(500.plus(i.key.toInt()), notifyBuild)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

然后就是通知一般我们都是service发出的，如何保持service一直运行呢

1.提高service优先级

2.从最近任务列表移除应用，防止主程序被杀掉

在主activity设置

```html
 android:excludeFromRecents="true"
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

3.开启前台通知（目前这个可以保持非常久，基本就是可见应用状态了，优先级很高）

这里开启前台服务，通知会一直出现在状态上，比如显示xx正在运行，你可以自定义的，修改notification内容就不写了。

```Kotlin
  startForeground(0x11,notifyBuildPre)
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

还有权限：

```Kotlin
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

![](https://img-blog.csdnimg.cn/20190602091710289.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=,size_16,color_FFFFFF,t_70)​

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

酷安传送门：[锁屏备忘录](https://www.coolapk.com/apk/232831)
