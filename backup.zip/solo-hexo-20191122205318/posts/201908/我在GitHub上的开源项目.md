title: 我在 GitHub 上的开源项目
date: '2019-08-20 19:44:56'
updated: '2019-08-20 19:44:56'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [YbConsole](https://github.com/iwh718/YbConsole) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/iwh718/YbConsole/watchers "关注数")&nbsp;&nbsp;[⭐️`9`](https://github.com/iwh718/YbConsole/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/iwh718/YbConsole/network/members "分叉数")</span>

易班开发者安卓客户端，查看轻应用，修改。



---

### 2. [fengcheLite](https://github.com/iwh718/fengcheLite) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/iwh718/fengcheLite/watchers "关注数")&nbsp;&nbsp;[⭐️`8`](https://github.com/iwh718/fengcheLite/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/iwh718/fengcheLite/network/members "分叉数")</span>

风车动漫第三方安卓端



---

### 3. [QingGuoWD](https://github.com/iwh718/QingGuoWD) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/iwh718/QingGuoWD/watchers "关注数")&nbsp;&nbsp;[⭐️`5`](https://github.com/iwh718/QingGuoWD/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/iwh718/QingGuoWD/network/members "分叉数")</span>

文达学院青果教务系统查成绩。



---

### 4. [TornadoFX-kotlinDesktopAPP](https://github.com/iwh718/TornadoFX-kotlinDesktopAPP) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/iwh718/TornadoFX-kotlinDesktopAPP/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/TornadoFX-kotlinDesktopAPP/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/iwh718/TornadoFX-kotlinDesktopAPP/network/members "分叉数")</span>

使用TornadoFx开发的校园助手桌面版，UI使用Jfoenix



---

### 5. [ReactRouterDemo](https://github.com/iwh718/ReactRouterDemo) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/iwh718/ReactRouterDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/ReactRouterDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/iwh718/ReactRouterDemo/network/members "分叉数")</span>

React-Router的练习



---

### 6. [MbaAs](https://github.com/iwh718/MbaAs) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/iwh718/MbaAs/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/MbaAs/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/iwh718/MbaAs/network/members "分叉数")</span>

二级Ms助手



---

### 7. [ReactFluxDemo](https://github.com/iwh718/ReactFluxDemo) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/iwh718/ReactFluxDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/ReactFluxDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/iwh718/ReactFluxDemo/network/members "分叉数")</span>

fluxDemo



---

### 8. [Kotlin_MVP_Demo](https://github.com/iwh718/Kotlin_MVP_Demo) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/iwh718/Kotlin_MVP_Demo/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/Kotlin_MVP_Demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/iwh718/Kotlin_MVP_Demo/network/members "分叉数")</span>

kotlin最简MVP的demo



---

### 9. [iExcel](https://github.com/iwh718/iExcel) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/iwh718/iExcel/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/iwh718/iExcel/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/iwh718/iExcel/network/members "分叉数")</span>

一个基于React的表格组件，demo实现了动态增删与全局提示，使用react:v16版与es6。



---

### 10. [YBAPI](https://github.com/iwh718/YBAPI) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/iwh718/YBAPI/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/iwh718/YBAPI/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/iwh718/YBAPI/network/members "分叉数")</span>

易班轻应用接口使用。

