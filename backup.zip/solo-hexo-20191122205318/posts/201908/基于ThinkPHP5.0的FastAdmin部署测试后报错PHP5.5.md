title: 基于ThinkPHP5.0的FastAdmin 部署测试后报错 PHP5.5
date: '2019-08-20 07:25:14'
updated: '2019-08-20 07:25:14'
tags: [FastAdmin, THinkPHP]
permalink: /articles/2019/08/20/1566257114123.html
---
这个问题其实很简单，主要是官方说Fa是支持5.5的PHP的，其实也是支持的，不过部分类库文件使用了5.6的可变参数这个语法，导致5.5的环境，部署后，打开首页就报错。

  

修改的方法也很简单：大概有2个类的8个函数要修改，将函数的参数...xxx删除 换成$xxx = func_num_args() ;

就可以解决了。
