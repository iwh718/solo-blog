title: Geany配置Python环境
date: '2019-09-05 12:02:00'
updated: '2019-09-05 12:02:24'
tags: [Python]
permalink: /articles/2019/09/05/1567656120620.html
---
![](https://img.hacpai.com/bing/20190722.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1.点击菜单
![image.png](https://img.hacpai.com/file/2019/09/image-a89aec33.png)

开始配置

我们只需要添加两个地方：第一个是compile，一个是execute、

第一个是python解释器的位置：右键python属性就可以复制路径，方法二是打开终端：python进入py终端 输入下图命令，路径出来了

![image.png](https://img.hacpai.com/file/2019/09/image-79a12be5.png)


![image.png](https://img.hacpai.com/file/2019/09/image-6867240c.png)

命令一：
`xxx\python -m py_compile "%f"`
命令二：
`xxx\python "%f"`

注意空格


还有执行前，把helloworld文件保存为py。。。
