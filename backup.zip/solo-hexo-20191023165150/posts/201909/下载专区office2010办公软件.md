title: 【下载专区】office2010办公软件
date: '2019-09-02 17:14:05'
updated: '2019-09-02 17:15:44'
tags: [下载专区]
permalink: /articles/2019/09/02/1567415645786.html
---
![](https://img.hacpai.com/bing/20181203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

❤️ 
Tips：有问题请留言哦！

1.有很多小伙伴安装了一些破解版的office软件，有些时候莫名其妙的就突然不能用了，或者总是出问题，安装新的office总是安装失败，这里提供一个office卸载工具，清理之前的版本。
附上地址：[](https://)[office卸载助手.zip](https://img.hacpai.com/file/2019/09/office卸载助手-e8b6722a.zip)

里面一共有三个：
Microsoft Fix it 50416是卸载office2003的，Microsoft Fix it 50154是卸载office2007的，Microsoft Fix it 50450是卸载office2010的。

这里顺便提一句：下载软件一定注意位数哦：目前大家的个人电脑普遍是64位的，所以注意哦，不要下载32的！

  1、office卸载工具运行不了，提示“Microsoft Fix it不适用于您的操作系统或应用程序版本”怎么办？

       遇到这个问题，先解压你下载的软件，然后鼠标右键你要运行的程序（比如Microsoft Fix it 50416），选择属性，在打开的界面中，选择“以兼容模式运行这个程序”。

       

![Office强力卸载工具](http://www.xitongzhijia.net/uploads/allimg/170711/53-1FG1143125546.jpg)

![Office强力卸载工具](http://www.xitongzhijia.net/uploads/allimg/170711/53-1FG1143440P8.jpg)

![Office强力卸载工具](http://www.xitongzhijia.net/uploads/allimg/170711/53-1FG1143139361.jpg)

       2、运行后出现如下黑框是怎么回事，软件没被卸载什么情况？

![Office强力卸载工具](http://www.xitongzhijia.net/uploads/allimg/170711/53-1FG1143J6251.jpg)

       出现这个黑框说明软件已经卸载完了，倒数第三行有End，如果运行完还没有卸载，可以先重启下电脑，如果重启电脑后还没有卸载，可能你运行错了卸载工具，要选对应的卸载工具才能卸载成功。

------------------
安装方法

　　1、安装Office2010前，切记要将之前的Office卸载干净，以免安装失败。将下载的Office2010压缩包右键选择解压，没有解压选项的用户需要先下载安装解压缩软件。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/170215/53-1F215094525347.jpg)

　　2、打开解压后的Office2010文件夹并双击运行setup.exe（Office2010无法运行或报错的，鼠标右键setup.exe选择“以管理员身份运行”）。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/170215/53-1F21509453c08.jpg)

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/170215/53-1F215094551J0.jpg)

　　3、选择“我接受此协议的条款”，继续下一步。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141232644.jpg)

　　4、点击“立即安装”进入下一步，Office2010默认安装在C盘，不想安装在C盘的用户可以选择“自定义”安装。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141245117.jpg)

　　5、程序开始进行安装，Office2010安装时间大概5-10分钟，请耐心等待安装，（如果Office2010安装失败，可能之前的Office没有卸载干净，请将之前安装的Office卸载干净再安装，推荐卸载工具：[Office强力卸载工具](http://www.xitongzhijia.net/soft/82032.html)）。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141301P0.jpg)

　　6、Office2010安装完毕，点击关闭。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-16123014131Y37.jpg)

Office2010激活

　　1、双击运行“Office 2010 Toolkit激活工具”（在下载的包中有该激活工具），Win8以上系统需右键选择“以管理员身份运行”（如果Office 2010 Toolkit激活工具无法使用，请先安装**[.net framework 4.0](http://www.xitongzhijia.net/soft/87445.html)**）。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/170215/53-1F21509460S19.jpg)

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/170215/53-1F215094F3R4.jpg)

　　2、单击“EZ-Activator”按钮，进行Office2010激活。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141433240.jpg)

　　3、Office2010激活完毕。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141505R4.jpg)

注意事项

　　1、**如果Office2010安装失败，一般是由于之前电脑中的Office系列没有卸载干净，先卸载后再安装Office2010。**

　　2、Office2010安装后要使用包中的激活工具进行激活，激活后Office就能免费使用了。

　　3、Office2010官方下载 免费完整版安装完后在桌面没有图标，可以在开始菜单中找到（开始菜单-所有程序-Microsoft Office），或鼠标右键菜单也可以直接新建Word、Excel、ppt等文档。

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-161230141541553.jpg)

![Office 2010 简体中文破解版（Office2010）](http://www.xitongzhijia.net/uploads/allimg/161230/53-16123014155A48.jpg)

常见问题

　　问：每次打开都需要重新配置为什么？

　　答：打开命令运行框，用win（windows旗帜按键）+r就可以打开，然后输入HKCU\Software\Microsoft\Office\14.0\Word\Options /v NoReReg /t REG_DWORD /d 1，按回车就可以了。

---------------------------------------------------------------------------------------
office2010内附激活工具
链接:  提取码: 7vz3 
[office2010点击下载](https://pan.baidu.com/s/1Etk2cfW8DfCniGk_XirAGw)









