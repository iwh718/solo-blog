title: Kotlin：安卓首页定时动画
date: '2019-08-20 07:13:54'
updated: '2019-08-20 07:13:54'
tags: [android, kotlin]
permalink: /articles/2019/08/20/1566256434359.html
---
这里分几个步骤：

1. 设置首页的Activity为启动页面
2. 重写onCreate中，调用两个函数，定义的动画函数，监听函数

首先，设置启动页面：在activity中添加intent过滤器，第一个动作是设置主页面，第二个具体的定义为启动页面，这里注意那个theme，我们设置的是全屏首页，所有要把actionbar去掉。

```Kotlin
 <activity
            android:name=".brow"
            android:label="我的借阅" />
        <activity android:name=".about" />
        <activity android:name=".history" />
        <activity android:name=".MainActivity"
            android:theme="@style/Theme.Design.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
  </activity>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

接下来，处理onCreate里面的部分。

```Kotlin
    var ass = AnimationSet(false)//动画对象
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var login_img = findViewById<ImageView>(R.id.login_img)//获取首页login
        setContentView(R.layout.activity_main)
        startAni()//启动动画
        iniNext()//监听启动完成以后，切换到其它页面

    }


    fun startAni() {
        //定义动画：参数：开始宽度伸缩X比例，结束宽度伸缩X比例，开始伸缩高度比例，结束高度伸缩比例，定义X锚点，定义Y锚点（现在是中心）
        val sa = ScaleAnimation(
                1f, 1.1f, 1f, 1.1f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f)

        sa.duration = 2000//2s
        sa.fillAfter = true
        ass.addAnimation(sa)
        login_img.startAnimation(ass)//启动动画
    }


    fun iniNext() {
        ass.setAnimationListener(object: Animation.AnimationListener {
        //kotlin实现匿名类，object：xx{override xxx}

            override fun onAnimationStart(Ani:Animation) {
                //Snackbar.make(mycontext,"欢迎使用",Snackbar.LENGTH_LONG).show()
                Toast.makeText(this@MainActivity,"欢迎使用",Toast.LENGTH_LONG).show()

            }


         override fun onAnimationRepeat(ani:Animation) {

            }

            //监听动画播放完

           override fun onAnimationEnd(ani:Animation){
               var intent=Intent(this@MainActivity,WDMain::class.java)
                startActivity(intent);//主界面
                finish()
            }
        })
    }
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

ok。
