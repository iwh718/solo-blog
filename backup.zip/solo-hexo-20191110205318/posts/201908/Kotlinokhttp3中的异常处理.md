title: Kotlin：okhttp3中的异常处理
date: '2019-08-20 07:14:53'
updated: '2019-08-20 07:14:53'
tags: [android]
permalink: /articles/2019/08/20/1566256493222.html
---
最近写一个网络爬虫，安卓端用得okhttp3，开发语言用得是kotlin，这这方面资料挺少的，就写一下吧，处理请求失败的情况，防止闪退！

```Kotlin
 val client = OkHttpClient.Builder().cookieJar(cookieJar).build() //初始化请求  
 val myinfo = FormBody.Builder().add("user", user).build()//请求表单
 var request = Request.Builder().url(this.logUrl).post(myinfo).build()//构建请求
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

接下来是具体的请求：

```Kotlin
   var response = this.client.newCall(request).enqueue(object : Callback {
                     //这里用的是enqueue是异步请求，可以重写Callback匿名类的方法
                    //kotlin匿名类用object：类名（）{}这里是用得lambda去了参数括号
                    override fun onResponse(call: Call, response: Response) {
                   //请求成功执行xxx
                        var resText = response.body()?.string()
                        var temResText: String? = resText
                        var doc = Jsoup.parse(temResText)
                        res = doc.getElementsByTag("script").html().toString()
                        if (isSuccLogin.containsMatchIn(res)) {
                        //这里是请求成功以后的处理代码，用handle异步发送数据到UI上
                            var msg: Message = Message()
                            msg.what = 1
                            var temData = Bundle()
                            temData.putString("user", user)
                            temData.putString("pw", pw)
                            msg.data = temData
                            hand.sendMessage(msg)


                        } else {
                            var msg: Message = Message()
                            msg.what = 6
                            hand.sendMessage(msg)
                            Log.d("re:", res)

                        }
                    }
                    //请求失败执行xxx
                    override fun onFailure(call: Call, e: IOException) {
                        var msg: Message = Message()
                        msg.what = 3
                        hand.sendMessage(msg)
                    }
                })

```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

这样，就不用担心直接崩溃了，可以在加个try与catch捕捉。。处理。
