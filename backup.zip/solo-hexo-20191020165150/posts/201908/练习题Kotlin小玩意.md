title: 练习题：Kotlin小玩意
date: '2019-08-29 11:57:23'
updated: '2019-09-02 17:23:22'
tags: [kotlin]
permalink: /articles/2019/08/29/1567051043104.html
---

kotlin 计算list数据个数转map
```
fun main(args: Array<String>) {
   
    val data = 1..100
    val preList = arrayListOf<Int>()
    var resMap = mutableMapOf<Int,Int>(1 to 0,2 to 0,3 to 0,4 to 0, 5 to 0)
   	for(item in data){
      preList.add( (1..5).random()) 
    }
    
    preList.forEach{
        with(resMap){
            this[it] = this[it]!! + 1      
        }
    }
    println(resMap)
   
}

```
