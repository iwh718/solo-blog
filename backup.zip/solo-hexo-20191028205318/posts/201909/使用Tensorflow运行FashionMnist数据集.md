title: 使用Tensorflow运行FashionMnist数据集
date: '2019-09-21 13:52:47'
updated: '2019-09-21 13:52:47'
tags: [tensorflow]
permalink: /articles/2019/09/21/1569045167650.html
---



近期有一个小项目要使用TF做，先把示例Demo跑一下。

这是一个服装的分类模型。

首先安装
keras

`pip install keras -i xxx(国内镜像)`

```
from __future__ import absolute_import, division, print_function, unicode_literals

# 导入TensorFlow和tf.keras
import tensorflow as tf
from tensorflow import keras

# 导入辅助库
import numpy as np
import matplotlib.pyplot as plt

print(tf.__version__)

```

输出测试一下，是否安装正常


下面开始导入模型

```
fashion_mnist = keras.datasets.fashion_mnist
(train_images, train_labels), (test_images, test_labels) = fashion_mnist.load_data()
```

然后运行main，下面IDE会提示是否进入命令行，进入后，可以实时输入计算，不用再重复导入模型了。

![image.png](https://img.hacpai.com/file/2019/09/image-04cef72c.png)

左下角就是命令行的使用，有面是变量区，右上角是图示


我们导入这个模型，有两个元组，四个数组，分别是待训练图片与标签，测试图片与标签
在命令行输入：
`
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
`

测试一下：训练集的 ：应该输出：(60000, 28, 28)
````
train_images.shape

````

使用图形库输出第一个图片，去除网格。

```
plt.figure()
plt.imshow(train_images[0])
plt.colorbar()
plt.grid(False)
plt.show()
```
![image.png](https://img.hacpai.com/file/2019/09/image-c2bdb967.png)

缩放像素值：

```
train_images = train_images / 255.0

test_images = test_images / 255.0
```
看一下数据集标签对应情况：

```
plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train_images[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[train_labels[i]])
plt.show()
```
设置网络层：这里有三层，第一层是把输入的图片有二维的转换为一维28*28的数组，第二层暂时不晓得干啥的，第三层是用来返回概率的，使用softMax函数，概率分布10和为1.

```
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),
    keras.layers.Dense(128, activation=tf.nn.relu),
    keras.layers.Dense(10, activation=tf.nn.softmax)
])

```

编译模型：这里设置优化器与损失函数

```
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])
```


开始训练：

```
model.fit(train_images, train_labels, epochs=5)

```

试试在测试集上的效果：

```
test_loss, test_acc = model.evaluate(test_images, test_labels)
print('Test accuracy:', test_acc)

```


进行预测：

```
predictions = model.predict(test_images)
predictions[0]
#输出最大概率那个
np.argmax(predictions[0])
#检查标签
test_labels[0]
```

over。





