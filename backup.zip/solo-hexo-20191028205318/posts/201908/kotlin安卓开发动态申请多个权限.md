title: kotlin：安卓开发动态申请多个权限
date: '2019-08-20 22:56:44'
updated: '2019-08-20 22:56:44'
tags: [android]
permalink: /articles/2019/08/20/1566313004016.html
---
应用接入支付宝的sdk，需要申请一些权限。

这里是kotlin的代码：

对了：6.0以后有3组，27个权限是需要动态申请的，具体，百度吧。

下面申请了两个权限（要在manifest文件注册哈）

```Kotlin
 //1、首先声明一个数组permissions，将需要的权限都放在里面
        val permissions = arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE)
        val mPermissionList = ArrayList<String>()
        val mRequestCode = 0x1//权限请求码
        fun initPermission() {
            mPermissionList.clear()
            for (permission in permissions) {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        permission
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    mPermissionList.add(permission)
                }
            }
            if (!mPermissionList.isEmpty()) {
                // 后续操作...
                    ActivityCompat.requestPermissions(this@MainActivity, permissions, mRequestCode)

            } else {
                Toast.makeText(this@MainActivity,"全部授予！",Toast.LENGTH_SHORT).show()
               
               
            }
        }
//重写
 override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
           0x1 -> for (i in 0 until grantResults.size) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED)   Toast.makeText(this,"您有未授予的权限，可能影响使用",Toast.LENGTH_SHORT).show()
            }

        }// 授权结束后的后续操作
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)
