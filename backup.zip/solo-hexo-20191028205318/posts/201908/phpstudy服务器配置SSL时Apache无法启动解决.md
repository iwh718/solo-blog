title: phpstudy服务器配置SSL时Apache无法启动解决
date: '2019-08-19 22:14:28'
updated: '2019-08-19 22:14:28'
tags: [APACHE, Bug修复]
permalink: /articles/2019/08/19/1566224068439.html
---
第一步：

启用PHP扩展ssl模块

第二步：

打开httpd.ini配置文件

LoadModule ssl_module modules/mod_ssl.so 将这行的注释的“#”去掉

Include extra/httpd-ssl.conf 将这行的注释的“#”去掉

  

接下来：extra/httpd-ssl.conf文件

  

1.ServerName 后面改成你的网站域名，可以不带端口号

DocumentRoot后面改成网站路径（注意：windows系统目录是反斜杠\）

SSLCertificateFile 后面改成server.crt文件路径，公钥（这里是相对目录用斜线/）  
SSLCertificateKeyFile 后面改成server.key文件路径，私钥  
SSLCertificateChainFile 后面改成ca.crt文件路径，根证书

2.apache可能重启会失败

打开cmd：

cd到apache\bin 执行 httpd.exe -t

会出现错误原因：模块缺失

  

AH00526: Syntax error on line 293 of D:/php_web/Apache24/conf/httpd.conf:

Invalid command 'Order', perhaps misspelled or defined by a module not included  
in the server configuration

  

这里提醒一下

  

apache2.4与2.2配置问题

在Apache2.4版本中，提供了由mod_authz_host支持的新的访问控制配置语法。而2.2版本中的Order、Allow等命令在新版本中也可以得到兼容，实现这个兼容功能的模块就是mod_access_compat。所以Load这个模块后，apache2.4就能识别这些语句了，所以在httpd配置文件里面把这行注释去除！

再来一次命令

![](https://img-blog.csdn.net/20180613215240116?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

现在重启apache服务器。

![](https://img-blog.csdn.net/20180613215312558?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTA5MTM0MTQ=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

下面是强制重定向到https

phpstudy配置指定路径访问https（仅供参考，可以不用）

RewriteEngine on

RewriteBase /

RewriteCond %{SERVER_PORT} !^443$

RewriteRule ^.*$ https://%{SERVER_NAME}%{REQUEST_URI} [L,R]

这里注意一下哦：建立一个无后缀的.htaccess文件

首先建立一个txt文件另存：格式：全部文件，名称：.htaccess

看看桌面是不是出来了。

看到这篇文章受到启发：谢谢作者https://www.cnblogs.com/haries/p/4677383.html

忍不住说一句：很多教程都是爬虫到处爬取的，很无语，都是一样的，甚至错误也是，不乏看到很多目录错误的尤其是斜线。折腾好久。
