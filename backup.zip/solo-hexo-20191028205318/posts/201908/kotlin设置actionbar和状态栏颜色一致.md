title: kotlin设置actionbar和状态栏颜色一致
date: '2019-08-20 07:19:28'
updated: '2019-08-20 07:19:28'
tags: [kotlin, android]
permalink: /articles/2019/08/20/1566256768108.html
---
首先在mainfest文件中设置主题：

```html
android:theme="@style/AppTheme
```

接下来去看看：这个主题继承了theme.M。。。的样式

下面item是自定义的会覆盖父类样式，这里注意，如果活动中继承了Appcompat要用compat主题，不然会闪退、

  

```Kotlin
 <style name="AppTheme" parent="android:Theme.Material.Light">
        <item name="android:colorPrimaryDark">@color/colorPrimaryDark</item><!--状态栏API低于21-->
        <item name="android:colorAccent">@color/colorAccent</item><!--强调色-->
        <item name="android:colorPrimary">@color/colorPrimaryDark</item><!--actionbar颜色-->
        <item name="android:statusBarColor">@color/colorPrimaryDark</item><!--高于AI21状态栏颜色-->
        <item name="android:actionMenuTextColor">@color/colorPrimary</item><!--标题颜色和菜单颜色都会被设置-->
    </style>
```

![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)

慢慢积累，android不是语言，需要一点点积累。加油。
